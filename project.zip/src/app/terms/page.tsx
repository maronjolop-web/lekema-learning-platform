'use client';

import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/app/logo';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="container mx-auto flex h-20 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 group" prefetch={false}>
          <Logo />
          <span className="text-2xl font-bold tracking-tighter font-headline text-primary">LeKeMa</span>
        </Link>
        <Button variant="ghost" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12 md:py-24 max-w-4xl">
        <div className="panel space-y-8">
          <div className="flex items-center gap-4 border-b border-primary/10 pb-6">
            <div className="bg-primary/10 p-3 rounded-2xl">
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl font-black font-headline text-primary tracking-tight">Terms of Service</h1>
              <p className="text-muted-foreground font-bold uppercase tracking-widest text-xs mt-1">Effective Date: March 22, 2026</p>
            </div>
          </div>

          <div className="space-y-6 text-foreground/90 font-medium leading-relaxed">
            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Acceptance of Terms</h2>
              <p>By accessing or using the LeKeMa platform, you agree to comply with and be bound by these Terms of Service. If you do not agree to these terms, please do not use the application.</p>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">User Responsibilities</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>You agree not to engage in any illegal activities through the platform.</li>
                <li>You will not attempt to hack, disrupt, or interfere with the LeKeMa application services.</li>
                <li>You are responsible for maintaining the security and confidentiality of your login credentials.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Account Rules</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>Users must provide accurate and truthful information during registration.</li>
                <li>We reserve the right to suspend or terminate accounts that violate these terms or engage in abusive behavior toward other members.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Intellectual Property</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>The LeKeMa platform design, features, and educational content are the property of the creators.</li>
                <li>Users retain ownership of content they upload, but grant LeKeMa a license to store and display such content as part of the application service.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Limitation of Liability</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>LeKeMa is provided "as is" and "as available." We do not guarantee the app will always be error-free or uninterrupted.</li>
                <li>We are not liable for any indirect, incidental, or consequential damages arising from your use of the platform.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Updates to Terms</h2>
              <p>We may update these Terms and the Privacy Policy from time to time. Users will be notified of major changes via the in-app notification system.</p>
            </section>

            <section className="space-y-3 pt-6 border-t">
              <h2 className="text-2xl font-bold font-headline text-primary">Agreement</h2>
              <p>By using LeKeMa, you acknowledge that you have read and agree to these Terms of Service and our Privacy Policy.</p>
            </section>
          </div>
        </div>
      </main>

      <footer className="py-8 border-t bg-card/40 text-center">
        <div className="flex flex-col items-center gap-1">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.3em]">Creators</p>
          <p className="text-xs font-bold text-primary">Levron James Bacalangco, Ken Role Barcebal, and Maron Jolo Ponsaran</p>
          <p className="text-[10px] text-muted-foreground mt-2">LeKeMa Platform &copy; 2026</p>
        </div>
      </footer>
    </div>
  );
}
