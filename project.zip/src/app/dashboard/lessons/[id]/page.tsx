'use client';

import React, { use } from 'react';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { useFirestore, useDoc, useCollection, useMemoFirebase } from '@/firebase';
import { doc, collection, query, where } from 'firebase/firestore';
import { YouTubeEmbed } from '@/components/app/youtube-embed';
import { Button } from '@/components/ui/button';
import { ArrowLeft, HelpCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useTranslation } from '@/hooks/use-translation';
import { Lesson, Quiz } from '@/lib/definitions';

export default function LessonDetailsPage(props: { params: Promise<{ id: string }> }) {
  const params = use(props.params);
  const id = params.id;
  const db = useFirestore();
  const { t } = useTranslation();
  
  const lessonRef = useMemoFirebase(() => doc(db, 'lessons', id), [db, id]);
  const { data: lesson, isLoading: lessonLoading } = useDoc<Lesson>(lessonRef);

  const quizzesQuery = useMemoFirebase(() => 
    query(collection(db, 'quizzes'), where('lessonId', '==', id)), 
  [db, id]);
  const { data: quizzes, isLoading: quizzesLoading } = useCollection<Quiz>(quizzesQuery);

  if (lessonLoading) {
    return (
      <div className="flex h-full items-center justify-center p-20 min-h-[400px]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!lesson) {
    notFound();
  }

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-6">
        <Button variant="outline" asChild>
            <Link href="/dashboard/lessons" prefetch={false}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t('back_to_lessons')}
            </Link>
        </Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
            <h1 className="text-4xl font-bold font-headline">{lesson.title}</h1>
            <YouTubeEmbed url={lesson.youtubeLink} />
            <div>
                <h2 className="text-2xl font-bold font-headline mb-2">{t('description')}</h2>
                <p className="text-muted-foreground whitespace-pre-wrap">{lesson.description}</p>
            </div>
        </div>
        <div className="space-y-6">
            <Card className="border-2 shadow-sm">
                <CardHeader>
                    <CardTitle className="font-headline flex items-center gap-2">
                        <HelpCircle className="text-primary"/>
                        {t('related_quizzes')}
                    </CardTitle>
                    <CardDescription>Test your knowledge on this lesson.</CardDescription>
                </CardHeader>
                <CardContent>
                    {quizzesLoading ? (
                        <div className="flex justify-center py-4">
                            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                        </div>
                    ) : quizzes && quizzes.length > 0 ? (
                        <ul className="space-y-2">
                            {quizzes.map(quiz => (
                                <li key={quiz.id}>
                                    <Button variant="secondary" className="w-full justify-start h-auto py-3 px-4 text-left border hover:border-primary/50 transition-colors" asChild>
                                        <Link href={`/dashboard/quizzes?quizId=${quiz.id}`} prefetch={false}>
                                            <div className="flex flex-col">
                                                <span className="font-semibold">{quiz.title}</span>
                                                <span className="text-xs text-muted-foreground">{t(quiz.difficulty.toLowerCase())} mode</span>
                                            </div>
                                        </Link>
                                    </Button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-muted-foreground text-center py-8 bg-muted/30 rounded-lg border-2 border-dashed">No quizzes available for this lesson yet.</p>
                    )}
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}