'use client';

import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import { ArrowRight, Youtube, Loader2 } from 'lucide-react';
import { useTranslation } from '@/hooks/use-translation';
import { Lesson } from '@/lib/definitions';

export default function StudentLessonsPage() {
  const db = useFirestore();
  const { t } = useTranslation();
  const lessonsQuery = useMemoFirebase(() => collection(db, 'lessons'), [db]);
  const { data: lessons, isLoading } = useCollection<Lesson>(lessonsQuery);

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center p-20">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold font-headline">{t('lessons')}</h1>
      </div>
      {lessons && lessons.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {lessons.map((lesson) => (
            <Card key={lesson.id} className="flex flex-col">
              <CardHeader>
                <CardTitle className="font-headline text-xl">{lesson.title}</CardTitle>
                <CardDescription className="line-clamp-3">{lesson.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto">
                <Button asChild className="w-full">
                  <Link href={`/dashboard/lessons/${lesson.id}`} prefetch={false}>
                    {t('start_lesson')} <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/30 py-20 text-center">
            <Youtube className="h-16 w-16 text-muted-foreground/50 mb-4" />
            <h2 className="text-xl font-semibold font-headline">No Lessons Available</h2>
            <p className="text-muted-foreground mt-2">The admin has not added any lessons yet. Please check back later.</p>
        </div>
      )}
    </div>
  );
}
