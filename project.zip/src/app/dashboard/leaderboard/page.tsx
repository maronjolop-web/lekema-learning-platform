'use client';

import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Trophy, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTranslation } from '@/hooks/use-translation';
import { User } from '@/lib/definitions';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';

export default function LeaderboardPage() {
  const db = useFirestore();
  const { t } = useTranslation();
  
  // Simplified query to avoid requiring a composite index for (role == 'student' AND points DESC)
  const leaderboardQuery = useMemoFirebase(() => 
    query(
      collection(db, 'users'), 
      orderBy('points', 'desc'),
      limit(200) // Fetch more to filter for students in memory
    ), 
  [db]);
  
  const { data: allUsers, isLoading, error } = useCollection<User>(leaderboardQuery);
  
  // Filter for students in memory to avoid index complexities
  const students = allUsers?.filter(u => u.role === 'student') || [];

  const getInitials = (name: string) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name.substring(0, 2);
  };

  const getRankColor = (rank: number) => {
    if (rank === 0) return 'text-yellow-500'; // Gold
    if (rank === 1) return 'text-gray-400';   // Silver
    if (rank === 2) return 'text-yellow-700'; // Bronze
    return 'text-muted-foreground';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-3xl">{t('leaderboard')}</CardTitle>
          <CardDescription>See how you rank among your fellow learners based on points earned from quizzes.</CardDescription>
        </CardHeader>
        <CardContent>
          {error ? (
            <div className="space-y-4">
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error loading leaderboard</AlertTitle>
                <AlertDescription>
                  {error.message || "We couldn't fetch the rankings. Please try again later."}
                </AlertDescription>
              </Alert>
              <Button onClick={() => window.location.reload()} variant="outline" className="w-full">
                Try Refreshing
              </Button>
            </div>
          ) : isLoading ? (
            <div className="flex flex-col items-center justify-center p-20 gap-4">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground font-medium">Fetching top learners...</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">{t('rank')}</TableHead>
                  <TableHead>{t('student')}</TableHead>
                  <TableHead className="text-right">{t('points')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.length > 0 ? (
                  students.map((student, index) => (
                    <TableRow key={student.id} className="group transition-colors">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <span className={cn('text-lg font-bold w-6 text-center', getRankColor(index))}>
                            {index < 3 ? <Trophy className="h-5 w-5 inline-block"/> : index + 1}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9 border-2 border-background shadow-sm">
                            <AvatarImage src={student.avatarUrl} alt={student.name} />
                            <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                          </Avatar>
                          <span className="font-semibold group-hover:text-primary transition-colors">{student.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-bold text-primary tabular-nums">
                        {(student.points || 0).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-20">
                       <div className="flex flex-col items-center gap-2">
                          <Trophy className="h-12 w-12 text-muted-foreground/30" />
                          <p className="text-muted-foreground font-medium">{t('no_students_yet') || "No students have joined the leaderboard yet."}</p>
                       </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
