'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useFirestore, useCollection, useMemoFirebase, useDoc } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { Card, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { HelpCircle, ArrowRight, Loader2, RefreshCcw, AlertTriangle } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import QuizTaker from '@/components/app/student/quiz-taker';
import { useTranslation } from '@/hooks/use-translation';
import { Quiz } from '@/lib/definitions';
import { cn } from '@/lib/utils';

export default function StudentQuizzesPage() {
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { t } = useTranslation();
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');
  
  const selectedQuizId = searchParams.get('quizId');

  const quizRef = useMemoFirebase(() => 
    selectedQuizId ? doc(db, 'quizzes', selectedQuizId) : null
  , [db, selectedQuizId]);
  
  const { data: specificQuiz, isLoading: isSpecificQuizLoading, error: specificQuizError } = useDoc<Quiz>(quizRef);

  const quizzesQuery = useMemoFirebase(() => collection(db, 'quizzes'), [db]);
  const { data: allQuizzes, isLoading: isListLoading } = useCollection<Quiz>(quizzesQuery);

  if (selectedQuizId) {
    if (isSpecificQuizLoading) {
      return (
        <div className="flex flex-col h-[70vh] items-center justify-center gap-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-lg font-medium text-muted-foreground animate-pulse">Preparing your assessment...</p>
        </div>
      );
    }
    
    if (specificQuizError || (selectedQuizId && !specificQuiz && !isSpecificQuizLoading)) {
      return (
        <div className="flex flex-col h-[70vh] items-center justify-center gap-6 p-6 text-center">
            <AlertTriangle className="h-16 w-16 text-destructive/50" />
            <div className="space-y-2">
                <h2 className="text-2xl font-bold font-headline">Quiz Not Found</h2>
                <p className="text-muted-foreground max-w-md">The quiz you are looking for might have been moved or deleted by the administrator.</p>
            </div>
            <Button asChild variant="outline">
                <Link href="/dashboard/quizzes" prefetch={false}>Return to Quiz List</Link>
            </Button>
        </div>
      );
    }

    if (specificQuiz) {
      return <QuizTaker quiz={specificQuiz} />;
    }
  }

  const filteredQuizzes = allQuizzes?.filter(q => 
    difficultyFilter === 'all' || q.difficulty === difficultyFilter
  ) || [];

  const difficultyColor = {
    'Easy': 'bg-green-100 text-green-800 border-green-200',
    'Normal': 'bg-blue-100 text-blue-800 border-blue-200',
    'Hard': 'bg-red-100 text-red-800 border-red-200'
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">{t('quizzes')}</h1>
          <p className="text-muted-foreground mt-1">Challenge yourself with quizzes in different modes.</p>
        </div>
        
        <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => window.location.reload()} title="Refresh Quizzes">
                <RefreshCcw className="h-4 w-4" />
            </Button>
            <Tabs value={difficultyFilter} onValueChange={setDifficultyFilter} className="w-full md:w-auto">
                <TabsList className="grid w-full grid-cols-4 md:w-[400px]">
                    <TabsTrigger value="all">{t('all_modes')}</TabsTrigger>
                    <TabsTrigger value="Easy">{t('easy')}</TabsTrigger>
                    <TabsTrigger value="Normal">{t('normal')}</TabsTrigger>
                    <TabsTrigger value="Hard">{t('hard')}</TabsTrigger>
                </TabsList>
            </Tabs>
        </div>
      </div>

      {isListLoading ? (
        <div className="flex flex-col h-64 items-center justify-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground animate-pulse">Loading assessments...</p>
        </div>
      ) : filteredQuizzes.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredQuizzes.map((quiz) => (
            <Card key={quiz.id} className="flex flex-col hover:shadow-md transition-all duration-300 hover:-translate-y-1">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className={cn("font-semibold", difficultyColor[quiz.difficulty])}>
                    {t(quiz.difficulty.toLowerCase())}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-medium">
                    {quiz.questions?.length || 0} Questions
                  </span>
                </div>
                <CardTitle className="font-headline text-xl leading-tight">{quiz.title}</CardTitle>
                <CardDescription className="line-clamp-2">Test your understanding with {t(quiz.difficulty.toLowerCase())} mode questions.</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto">
                <Button asChild className="w-full glow" variant="default">
                  <Link href={`/dashboard/quizzes?quizId=${quiz.id}`} prefetch={false}>
                    {t('take_quiz')} <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-muted-foreground/20 py-24 text-center bg-card/50">
            <HelpCircle className="h-16 w-16 text-muted-foreground/30 mb-4" />
            <h2 className="text-2xl font-bold font-headline">
                {difficultyFilter === 'all' ? 'No Quizzes Available' : 'No Quizzes in this Mode'}
            </h2>
            <p className="text-muted-foreground mt-2 max-w-xs mx-auto">
              {difficultyFilter === 'all' 
                ? 'Check back later as the admin adds more learning assessments.' 
                : `There are currently no ${t(difficultyFilter.toLowerCase())} mode quizzes available.`}
            </p>
            <Button variant="outline" onClick={() => difficultyFilter !== 'all' ? setDifficultyFilter('all') : window.location.reload()} className="mt-6">
              {difficultyFilter !== 'all' ? 'View all quizzes' : 'Try Refreshing'}
            </Button>
        </div>
      )}
    </div>
  );
}