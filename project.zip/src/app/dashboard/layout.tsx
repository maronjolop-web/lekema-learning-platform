'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { BookCopy, Home, Loader2, LogOut, PanelLeft, Trophy, Users, Zap } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import Logo from '@/components/app/logo';
import { UserNav } from '@/components/app/user-nav';
import { cn } from '@/lib/utils';
import { useTranslation } from '@/hooks/use-translation';
import { ModeToggle } from '@/components/mode-toggle';
import NotificationBell from '@/components/app/notification-bell';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const { t } = useTranslation();
  const router = useRouter();
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && !isLoading && !user) {
      router.replace('/login');
    }
  }, [user, isLoading, router, mounted]);

  if (!mounted || (isLoading && !user)) {
    return (
      <div className="flex h-screen items-center justify-center bg-background/80 backdrop-blur-md">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm font-bold text-primary tracking-widest uppercase animate-pulse">Launching LeKeMa...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const navItems = [
    { href: '/dashboard/lessons', icon: BookCopy, label: t('lessons') },
    { href: '/dashboard/quizzes', icon: Home, label: t('quizzes') },
    { href: '/dashboard/leaderboard', icon: Trophy, label: t('leaderboard') },
    { href: '/dashboard/members', icon: Users, label: t('members') },
  ];
  
  const navContent = (
    <nav className="flex flex-col h-full text-lg font-medium p-6">
      <Link
        href="/dashboard"
        className="flex items-center gap-2 text-lg font-semibold mb-8"
        prefetch={false}
      >
        <Logo />
        <span className="font-headline tracking-tight">LeKeMa</span>
      </Link>
      <div className="grid gap-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 transition-all",
                pathname.startsWith(item.href) 
                  ? "text-primary bg-muted/60 font-bold" 
                  : "text-muted-foreground hover:text-primary hover:bg-muted/30"
              )}
            prefetch={false}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Link>
        ))}
      </div>
    </nav>
  );

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr] bg-transparent">
      <div className="hidden border-r md:block bg-card border-border shadow-lg">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6 border-border">
            <Link href="/dashboard" className="flex items-center gap-2 font-semibold" prefetch={false}>
              <Logo />
              <span className="font-headline tracking-tight text-primary">LeKeMa</span>
            </Link>
          </div>
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4 mt-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 transition-all mb-1",
                    pathname.startsWith(item.href) 
                      ? "text-primary bg-primary/10 font-bold"
                      : "text-muted-foreground hover:text-primary hover:bg-muted/30"
                  )}
                  prefetch={false}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="mt-auto p-4 flex flex-col gap-4 border-t border-border">
            <div className="flex justify-center">
              <ModeToggle />
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              className="w-full justify-start text-muted-foreground hover:text-destructive font-bold" 
              onClick={logout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              {t('logout')}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex flex-col min-h-screen relative overflow-auto bg-transparent">
        <header className="flex h-14 items-center gap-4 border-b px-4 lg:h-[60px] lg:px-6 z-10 sticky top-0 bg-background border-border shadow-sm">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="shrink-0 md:hidden">
                <PanelLeft className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 bg-card border-r shadow-2xl">
              <SheetHeader className="sr-only">
                <SheetTitle>Navigation Menu</SheetTitle>
                <SheetDescription>Access learning features and community tools.</SheetDescription>
              </SheetHeader>
              {navContent}
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1">
            <h2 className="text-lg font-bold font-headline hidden md:block text-primary">Learning Dashboard</h2>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <div className="hidden sm:flex items-center gap-2 bg-primary/10 px-4 py-1.5 rounded-full border border-primary/20">
               <Zap className="h-4 w-4 text-primary fill-primary" />
               <span className="text-sm font-bold text-primary tabular-nums">{user?.points?.toLocaleString() ?? 0} {t('points_short')}</span>
            </div>
            <NotificationBell />
            <ModeToggle />
            <UserNav />
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 bg-transparent">
          <div className="flex-1 max-w-7xl mx-auto w-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}