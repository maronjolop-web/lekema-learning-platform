'use client';

import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, limit } from 'firebase/firestore';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { useTranslation } from '@/hooks/use-translation';
import { Loader2, Users, Eye } from 'lucide-react';
import { User } from '@/lib/definitions';
import ChatDialog from '@/components/app/chat-dialog';
import AnnouncementBoard from '@/components/app/announcement-board';
import ProfileForm from '@/components/app/profile-form';

export default function MembersPage() {
  const db = useFirestore();
  const { t } = useTranslation();

  const membersQuery = useMemoFirebase(() => 
    query(
      collection(db, 'users'), 
      limit(100)
    ), 
  [db]);
  const { data: allUsers, isLoading } = useCollection<User>(membersQuery);

  const students = allUsers?.filter(u => u.role === 'student') || [];
  const admins = allUsers?.filter(u => u.role === 'admin') || [];

  const getInitials = (name: string) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name.substring(0, 2);
  };
  
  return (
    <div className="space-y-8">
        <AnnouncementBoard />
        
        <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-3 space-y-8">
                <div className="flex items-center gap-3 mb-6">
                    <Users className="h-8 w-8 text-primary" />
                    <h1 className="text-3xl font-bold font-headline">{t('members')}</h1>
                </div>

                {isLoading ? (
                    <div className="flex justify-center p-20">
                        <Loader2 className="h-10 w-10 animate-spin text-primary" />
                    </div>
                ) : (
                    <div className="space-y-12">
                        <section>
                            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-muted-foreground mb-6">Administrators</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                {admins.map((admin) => (
                                    <Card key={admin.id} className="hover:shadow-lg transition-all border-l-4 border-l-accent group shadow-md">
                                        <CardContent className="flex items-center p-4 gap-4">
                                            <ProfileForm user={admin}>
                                              <button className="relative group/avatar">
                                                <Avatar className="w-14 h-14 border-2 border-accent transition-transform group-hover/avatar:scale-105">
                                                    <AvatarImage src={admin.avatarUrl} alt={admin.name} />
                                                    <AvatarFallback>{getInitials(admin.name)}</AvatarFallback>
                                                </Avatar>
                                                <div className="absolute inset-0 bg-accent/20 rounded-full opacity-0 group-hover/avatar:opacity-100 flex items-center justify-center transition-opacity">
                                                  <Eye className="h-5 w-5 text-white drop-shadow-md" />
                                                </div>
                                              </button>
                                            </ProfileForm>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-bold truncate text-lg text-[#001a33] dark:text-foreground">{admin.name}</p>
                                                <p className="text-[10px] uppercase font-black text-accent tracking-widest">Admin Support</p>
                                            </div>
                                            <div className="flex items-center gap-1">
                                              <ChatDialog targetUser={admin} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </section>

                        <section>
                            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-muted-foreground mb-6">Fellow Students</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                {students.map((student) => (
                                    <Card key={student.id} className="hover:shadow-lg transition-all border-l-4 border-l-primary group shadow-md">
                                        <CardContent className="flex items-center p-4 gap-4">
                                            <ProfileForm user={student}>
                                              <button className="relative group/avatar">
                                                <Avatar className="w-14 h-14 border-2 border-primary transition-transform group-hover/avatar:scale-105">
                                                    <AvatarImage src={student.avatarUrl} alt={student.name} />
                                                    <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                                                </Avatar>
                                                <div className="absolute inset-0 bg-primary/20 rounded-full opacity-0 group-hover/avatar:opacity-100 flex items-center justify-center transition-opacity">
                                                  <Eye className="h-5 w-5 text-white drop-shadow-md" />
                                                </div>
                                              </button>
                                            </ProfileForm>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-bold truncate text-lg text-[#001a33] dark:text-foreground">{student.name}</p>
                                                <p className="text-xs text-muted-foreground font-medium">{student.points} {t('points_short')}</p>
                                            </div>
                                            <div className="flex items-center gap-1">
                                              <ChatDialog targetUser={student} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </section>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
}