import Link from "next/link";
import Logo from "@/components/app/logo";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-secondary/50 p-4">
        <div className="absolute top-4 left-4">
            <Link href="/" className="flex items-center gap-2 text-lg font-semibold" prefetch={false}>
                <Logo />
                <span className="font-headline tracking-tight">LeKeMa</span>
            </Link>
        </div>
      {children}
    </div>
  );
}
