'use client';

import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, limit, orderBy } from 'firebase/firestore';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Loader2, AlertCircle, RefreshCw, Users as UsersIcon, MessageSquare } from 'lucide-react';
import MembersTable from '@/components/app/admin/members-table';
import { User } from '@/lib/definitions';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useState } from 'react';
import AnnouncementBoard from '@/components/app/announcement-board';

export default function AdminMembersPage() {
  const db = useFirestore();
  const [activeTab, setActiveTab] = useState('all');
  
  const membersQuery = useMemoFirebase(() => 
    query(
      collection(db, 'users'), 
      orderBy('name', 'asc'),
      limit(1000)
    ), 
  [db]);

  const { data: allUsers, isLoading, error } = useCollection<User>(membersQuery);
  
  const students = allUsers?.filter(u => u.role === 'student') || [];
  const admins = allUsers?.filter(u => u.role === 'admin') || [];

  return (
    <div className="space-y-8">
      <AnnouncementBoard />
      
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold font-headline">Member Directory</h1>
            <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
              <RefreshCw className="mr-2 h-4 w-4" /> Refresh
            </Button>
          </div>

          {error ? (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {error.message || "Unable to fetch the member directory."}
              </AlertDescription>
            </Alert>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All ({allUsers?.length || 0})</TabsTrigger>
                <TabsTrigger value="students">Students ({students.length})</TabsTrigger>
                <TabsTrigger value="admins">Admins ({admins.length})</TabsTrigger>
              </TabsList>

              <Card className="border-2 shadow-md">
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>
                    {activeTab === 'all' && "Viewing all registered accounts."}
                    {activeTab === 'students' && "Viewing all student accounts."}
                    {activeTab === 'admins' && "Viewing administrative accounts."}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {isLoading ? (
                    <div className="flex flex-col items-center justify-center p-20 gap-4">
                      <Loader2 className="h-10 w-10 animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">Loading members...</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto min-h-[400px]">
                      <TabsContent value="all" className="m-0 border-none">
                        {allUsers && allUsers.length > 0 ? (
                          <MembersTable students={allUsers} showRole />
                        ) : (
                          <EmptyState />
                        )}
                      </TabsContent>
                      <TabsContent value="students" className="m-0 border-none">
                         {students.length > 0 ? (
                          <MembersTable students={students} />
                        ) : (
                          <EmptyState message="No student accounts found." />
                        )}
                      </TabsContent>
                      <TabsContent value="admins" className="m-0 border-none">
                         {admins.length > 0 ? (
                          <MembersTable students={admins} showRole />
                        ) : (
                          <EmptyState message="No administrative accounts found." />
                        )}
                      </TabsContent>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Tabs>
          )}
        </div>

        <div className="space-y-6">
          <Card className="border-2 border-accent/20 shadow-md">
            <CardHeader className="bg-accent/5">
              <CardTitle className="text-sm font-headline uppercase tracking-widest flex items-center gap-2 text-[#001a33] dark:text-foreground">
                <MessageSquare className="h-4 w-4" /> Support Tips
              </CardTitle>
            </CardHeader>
            <CardContent className="text-xs space-y-2 text-muted-foreground pt-4">
              <p>• Use the "Message" icon in the table actions to start a private chat with any student.</p>
              <p>• Public Notes are broadcasted to all members instantly.</p>
              <p>• Communication history is preserved for support auditing.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ message = "No records found." }: { message?: string }) {
  return (
    <div className="text-center py-20">
      <UsersIcon className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
      <p className="text-muted-foreground font-medium">{message}</p>
    </div>
  );
}