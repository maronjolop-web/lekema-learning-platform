'use client';

import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Trophy, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { User } from '@/lib/definitions';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function AdminLeaderboardPage() {
  const db = useFirestore();
  
  // Simplified query to avoid requiring a composite index for (role == 'student' AND points DESC)
  const leaderboardQuery = useMemoFirebase(() => 
    query(
      collection(db, 'users'), 
      orderBy('points', 'desc'),
      limit(200) // Fetch a larger set to filter students in memory
    ), 
  [db]);
  
  const { data: allUsers, isLoading, error } = useCollection<User>(leaderboardQuery);
  
  // Filter for students in memory
  const students = allUsers?.filter(u => u.role === 'student') || [];

  const getInitials = (name: string) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name.substring(0, 2);
  };

  const getRankColor = (rank: number) => {
    if (rank === 0) return 'text-yellow-500';
    if (rank === 1) return 'text-gray-400';
    if (rank === 2) return 'text-yellow-700';
    return 'text-muted-foreground';
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline text-3xl">Leaderboard Management</CardTitle>
        <CardDescription>Comprehensive student rankings based on total points earned.</CardDescription>
      </CardHeader>
      <CardContent>
        {error ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Database Error</AlertTitle>
            <AlertDescription>
              {error.message}
            </AlertDescription>
          </Alert>
        ) : isLoading ? (
          <div className="flex flex-col items-center justify-center p-12 gap-2">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Loading student data...</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">Rank</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Points</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students && students.length > 0 ? (
                students.map((student, index) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span className={cn('text-lg font-bold w-6 text-center', getRankColor(index))}>
                          {index < 3 ? <Trophy className="h-5 w-5 inline-block"/> : index + 1}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={student.avatarUrl} alt={student.name} />
                          <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                           <p className="font-medium">{student.name}</p>
                           <p className="text-xs text-muted-foreground">{student.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={cn('text-xs font-semibold px-2 py-1 rounded-full', student.isBlocked ? 'bg-destructive/20 text-destructive-foreground' : 'bg-primary/20 text-primary')}>
                        {student.isBlocked ? 'Blocked' : 'Active'}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-bold text-primary tabular-nums">
                      {student.points?.toLocaleString() ?? 0}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-12 text-muted-foreground font-medium">
                    No students found in the database.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
