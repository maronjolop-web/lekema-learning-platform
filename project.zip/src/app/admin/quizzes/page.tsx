'use client';

import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { PlusCircle, Loader2 } from 'lucide-react';
import QuizForm from '@/components/app/admin/quiz-form';
import { Quiz, Lesson } from '@/lib/definitions';

export default function AdminQuizzesPage() {
  const db = useFirestore();
  
  const lessonsQuery = useMemoFirebase(() => collection(db, 'lessons'), [db]);
  const { data: lessons, isLoading: lessonsLoading } = useCollection<Lesson>(lessonsQuery);

  const quizzesQuery = useMemoFirebase(() => collection(db, 'quizzes'), [db]);
  const { data: quizzes, isLoading: quizzesLoading } = useCollection<Quiz>(quizzesQuery);

  const lessonMap = new Map(lessons?.map(l => [l.id, l.title]) || []);

  const isLoading = lessonsLoading || quizzesLoading;

  return (
    <div>
       <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold font-headline">Manage Quizzes</h1>
        {lessons && lessons.length > 0 && (
          <QuizForm lessons={lessons}>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Quiz
            </Button>
          </QuizForm>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center p-12">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      ) : quizzes && quizzes.length > 0 ? (
        <div className="space-y-6">
          {quizzes.map((quiz) => (
            <Card key={quiz.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{quiz.title}</CardTitle>
                    <CardDescription>
                      Associated with lesson: &quot;{lessonMap.get(quiz.lessonId) || 'Unknown'}&quot;
                      {' | '} {quiz.questions?.length || 0} questions
                    </CardDescription>
                  </div>
                  {lessons && (
                    <QuizForm quiz={quiz} lessons={lessons}>
                        <Button variant="outline">Manage</Button>
                    </QuizForm>
                  )}
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 border-2 border-dashed rounded-lg bg-card/50">
          <h2 className="text-xl font-semibold">No quizzes found</h2>
          <p className="text-muted-foreground mt-1">Add a quiz to a lesson to get started.</p>
        </div>
      )}
    </div>
  );
}
