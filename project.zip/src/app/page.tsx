'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Smartphone, LogIn, Loader2, WifiOff, Trophy, Zap } from 'lucide-react';
import Logo from '@/components/app/logo';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ModeToggle } from '@/components/mode-toggle';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';

export default function Home() {
  const { toast } = useToast();
  const { user, role, isLoading } = useAuth();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const logoImage = PlaceHolderImages.find(p => p.id === 'app-logo');

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && !isLoading && user) {
      router.replace(role === 'admin' ? '/admin' : '/dashboard');
    }
  }, [user, role, isLoading, router, mounted]);

  const handleDownloadApp = () => {
    toast({
      title: "Install LeKeMa",
      description: "To download LeKeMa, tap 'Add to Home Screen' in your browser menu for the full native experience.",
    });
  };

  if (!mounted || (isLoading && !user)) {
    return (
      <div className="flex h-screen items-center justify-center bg-background/80 backdrop-blur-md">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm font-bold text-primary tracking-widest uppercase animate-pulse">Launching LeKeMa...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col relative">
      <header className="container mx-auto flex h-20 items-center justify-between px-4 md:px-6 z-50">
        <Link href="/" className="flex items-center gap-2 group" prefetch={false}>
          <Logo />
          <span className="text-2xl font-bold tracking-tighter font-headline text-foreground group-hover:scale-105 transition-transform">LeKeMa</span>
        </Link>
        <div className="flex items-center gap-4">
          <ModeToggle />
          <Link href="/login" prefetch={false} className="premium-btn py-2 px-6 flex items-center gap-2 text-sm">
            <LogIn className="h-4 w-4" />
            <span>Login</span>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 flex justify-center">
          <div className="container px-4 md:px-6 max-w-4xl">
            <div className="panel flex flex-col items-center text-center space-y-10">
              <div className="space-y-4">
                <h1 className="text-5xl font-black tracking-tight sm:text-6xl xl:text-7xl font-headline text-foreground">
                  Master Skills with LeKeMa
                </h1>
                <p className="max-w-[600px] mx-auto opacity-80 font-bold md:text-lg leading-relaxed text-foreground">
                  The elite interactive platform for modern learners. High-quality video lessons, competitive assessments, and real-time achievement tracking.
                </p>
              </div>

              <div className="flex flex-col gap-4 sm:flex-row pt-4 w-full justify-center">
                <Link href="/register" prefetch={false} className="premium-btn text-center text-base px-10 glow">
                  GET STARTED
                </Link>
                <button 
                  className="premium-btn !bg-[#003366] flex gap-2 items-center justify-center px-10" 
                  onClick={handleDownloadApp}
                >
                  <Smartphone className="h-5 w-5" />
                  INSTALL APP
                </button>
              </div>

              <div className="relative w-full max-w-[300px] aspect-square rounded-3xl overflow-hidden shadow-2xl border-4 border-white/30">
                {logoImage ? (
                  <Image
                    src={logoImage.imageUrl}
                    alt="LeKeMa Logo"
                    fill
                    className="object-cover"
                    priority
                  />
                ) : (
                  <div className="w-full h-full bg-blue-500/20 flex items-center justify-center">
                    <Zap className="h-20 w-20 text-white" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-20 bg-transparent">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="panel flex flex-col gap-4 hover:translate-y-[-5px] transition-all duration-300 h-full border-2 border-border">
                <div className="bg-primary p-3 rounded-xl w-fit shadow-md">
                  <WifiOff className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold font-headline">Offline Access</h3>
                <p className="opacity-80 font-bold text-sm leading-relaxed text-foreground">
                  Continue your LeKeMa journey anywhere. Lessons and quizzes are available offline and sync automatically.
                </p>
              </div>
              <div className="panel flex flex-col gap-4 hover:translate-y-[-5px] transition-all duration-300 h-full border-2 border-border">
                <div className="bg-primary p-3 rounded-xl w-fit shadow-md">
                  <Smartphone className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold font-headline">Mobile First</h3>
                <p className="opacity-80 font-bold text-sm leading-relaxed text-foreground">
                  Optimized for the "Installed App" experience. Add LeKeMa to your home screen for instant access.
                </p>
              </div>
              <div className="panel flex flex-col gap-4 hover:translate-y-[-5px] transition-all duration-300 h-full border-2 border-border">
                <div className="bg-primary p-3 rounded-xl w-fit shadow-md">
                  <Trophy className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold font-headline">Smart Sync</h3>
                <p className="opacity-80 font-bold text-sm leading-relaxed text-foreground">
                  Seamless achievement tracking across all devices. Your points and progress are always up to date.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="container mx-auto py-10 w-full px-4 md:px-6 border-t border-foreground/10 flex flex-col gap-4 sm:flex-row items-center justify-between">
        <div className="text-xs font-bold space-y-1">
          <p>LeKeMa Platform &copy; 2026</p>
          <div className="opacity-80">
            <span className="uppercase tracking-widest text-[10px] block mb-1">Creators</span>
            <p className="text-primary font-black">Levron James Bacalangco, Ken Role Barcebal, and Maron Jolo Ponsaran</p>
          </div>
        </div>
        <nav className="flex gap-6">
          <Link href="/terms" className="text-xs font-bold hover:underline" prefetch={false}>TERMS</Link>
          <Link href="/privacy" className="text-xs font-bold hover:underline" prefetch={false}>PRIVACY</Link>
        </nav>
      </footer>
    </div>
  );
}
