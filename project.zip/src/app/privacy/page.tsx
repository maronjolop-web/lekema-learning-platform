'use client';

import Link from 'next/link';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/app/logo';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="container mx-auto flex h-20 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 group" prefetch={false}>
          <Logo />
          <span className="text-2xl font-bold tracking-tighter font-headline text-primary">LeKeMa</span>
        </Link>
        <Button variant="ghost" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
          </Link>
        </Button>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12 md:py-24 max-w-4xl">
        <div className="panel space-y-8">
          <div className="flex items-center gap-4 border-b border-primary/10 pb-6">
            <div className="bg-primary/10 p-3 rounded-2xl">
              <ShieldCheck className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl font-black font-headline text-primary tracking-tight">Privacy Policy</h1>
              <p className="text-muted-foreground font-bold uppercase tracking-widest text-xs mt-1">Effective Date: March 22, 2026</p>
            </div>
          </div>

          <div className="space-y-6 text-black font-bold leading-relaxed">
            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Information We Collect</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Personal information:</strong> Name, email address, and encrypted login credentials.</li>
                <li><strong>User content:</strong> Learning progress, quiz results, messages, and any files uploaded to your profile.</li>
                <li><strong>Device information:</strong> Device type, operating system, and anonymous usage statistics to improve the app experience.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">How We Use Your Information</h2>
              <p>We use the collected data to:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Operate and maintain the LeKeMa learning platform.</li>
                <li>Personalize your learning journey and track achievements.</li>
                <li>Provide customer support and respond to your messages.</li>
                <li>Send important system notifications and updates.</li>
              </ul>
            </section>

            <section className="space-y-3">
              <h2 className="text-2xl font-bold font-headline text-primary">Data Storage & Security</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li>Data is securely stored and managed using <strong>Google Firebase</strong>.</li>
                <li>We apply industry-standard encryption and security measures to protect your account.</li>
                <li>We use memory-only caching where possible to prevent unauthorized local data access.</li>
              </ul>
            </section>

            <section className="space-y-3 pt-6 border-t">
              <h2 className="text-2xl font-bold font-headline text-primary">Contact Information</h2>
              <p>If you have any questions regarding this Privacy Policy, please reach out to us:</p>
              <p className="font-bold">Email: <a href="mailto:lekema@gmail.com" className="text-primary underline">lekema@gmail.com</a></p>
            </section>
          </div>
        </div>
      </main>

      <footer className="py-8 border-t bg-card/40 text-center">
        <div className="flex flex-col items-center gap-1">
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.3em]">Creators</p>
          <p className="text-xs font-bold text-primary">Levron James Bacalangco, Ken Role Barcebal, and Maron Jolo Ponsaran</p>
          <p className="text-[10px] text-muted-foreground mt-2">LeKeMa Platform &copy; 2026</p>
        </div>
      </footer>
    </div>
  );
}
