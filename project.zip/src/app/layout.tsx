import type { Metadata, Viewport } from 'next';
import { AuthProvider } from '@/lib/auth';
import { Toaster } from '@/components/ui/toaster';
import { FirebaseClientProvider } from '@/firebase';
import { ThemeProvider } from '@/components/theme-provider';
import UniversalLogicListener from '@/components/app/universal-logic-listener';
import LoadingManager from '@/components/app/loading-manager';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'lekema | Elite Interactive Learning',
    template: '%s | LeKeMa'
  },
  description: 'lekema (LeKeMa) is an elite modern learning platform featuring high-visibility lessons, competitive quizzes, and real-time achievements.',
  keywords: ['lekema', 'LeKeMa', 'learning', 'education', 'quizzes', 'elite lessons'],
  manifest: '/manifest.json',
  icons: {
    icon: 'https://i.ibb.co/vCbtgP0G/619367173-1099334822277102-3628089425914671011-n.png',
    apple: 'https://i.ibb.co/vCbtgP0G/619367173-1099334822277102-3628089425914671011-n.png',
  },
};

export const viewport: Viewport = {
  themeColor: '#001a33',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const bgImage = PlaceHolderImages.find(p => p.id === 'global-bg');
  const logoImage = PlaceHolderImages.find(p => p.id === 'app-logo');

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet" />
        
        {/* ✅ PRELOAD CRITICAL ASSETS FOR FASTEST LOAD ON SLOW CONNECTIONS */}
        {logoImage && <link rel="preload" as="image" href={logoImage.imageUrl} />}
        {bgImage && <link rel="preload" as="image" href={bgImage.imageUrl} />}
        
        {/* ✅ INJECT GLOBAL BACKGROUND CSS VARIABLE FOR ZERO-LATENCY PAINT */}
        {bgImage && (
          <style dangerouslySetInnerHTML={{ __html: `
            :root {
              --global-bg-url: url("${bgImage.imageUrl}");
            }
          `}} />
        )}
      </head>
      <body className="font-body antialiased selection:bg-primary/30 selection:text-primary">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
          themes={['light', 'dark', 'science']}
        >
          <FirebaseClientProvider>
            <AuthProvider>
              <LoadingManager />
              <UniversalLogicListener />
              {children}
              <Toaster />
            </AuthProvider>
          </FirebaseClientProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}