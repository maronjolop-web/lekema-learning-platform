'use client';

import { useAuth } from '@/lib/auth';
import { translations, Language } from '@/lib/translations';

export function useTranslation() {
  const { user } = useAuth();
  const lang = (user?.language as Language) || 'English';

  const t = (key: string) => {
    return translations[lang]?.[key] || translations['English'][key] || key;
  };

  return { t, lang };
}
