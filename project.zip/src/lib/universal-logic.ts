'use client';
/**
 * @fileOverview Universal Logic for LeKeMa.
 * Handles dynamic actions (Delete, Edit, Upload) using non-blocking Firebase mutations.
 * Designed to work seamlessly with real-time listeners.
 */

import { doc, getFirestore, serverTimestamp } from 'firebase/firestore';
import { 
  deleteDocumentNonBlocking, 
  updateDocumentNonBlocking
} from '@/firebase/non-blocking-updates';
import { toast } from '@/hooks/use-toast';

export const universalLogic = {
  /**
   * Deletes a document from any collection.
   * UI updates automatically via Firestore's onSnapshot listeners.
   */
  handleDelete(collectionName: string, id: string) {
    const db = getFirestore();
    const docRef = doc(db, collectionName, id);
    deleteDocumentNonBlocking(docRef);
    toast({ 
        title: "Item Deleted", 
        description: "The item has been removed from the platform.",
    });
  },

  /**
   * Updates a document with new content.
   * UI updates automatically via Firestore's onSnapshot listeners.
   */
  handleEdit(collectionName: string, id: string, data: any) {
    const db = getFirestore();
    const docRef = doc(db, collectionName, id);
    updateDocumentNonBlocking(docRef, { 
        ...data, 
        updatedAt: serverTimestamp() 
    });
    toast({ 
        title: "Update Successful", 
        description: "The changes have been applied successfully.",
    });
  },

  /**
   * Placeholder for future universal creation logic.
   */
  handleCreate(collectionName: string, data: any) {
    console.log(`Universal Create initiated for ${collectionName}`);
  }
};
