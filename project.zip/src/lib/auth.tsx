'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from 'firebase/auth';
import { doc, onSnapshot, setDoc, increment } from 'firebase/firestore';
import { useAuth as useFirebaseAuth, useFirestore, updateDocumentNonBlocking } from '@/firebase';
import { User } from '@/lib/definitions';

interface AuthContextType {
  user: User | null;
  role: 'admin' | 'student' | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; message: string; role?: string }>;
  register: (name: string, email: string, pass: string) => Promise<{ success: boolean; message: string; role?: string }>;
  logout: () => void;
  updateUserPoints: (userId: string, points: number) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_EMAIL = 'lekema@gmail.com';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<'admin' | 'student' | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const auth = useFirebaseAuth();
  const db = useFirestore();
  const router = useRouter();

  useEffect(() => {
    // Force persistent login session for the "Installed App" feel
    setPersistence(auth, browserLocalPersistence).catch((err) => {
      console.warn("Auth persistence failed:", err);
    });

    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        const emailLower = fbUser.email?.toLowerCase();
        const isAdminEmail = emailLower === ADMIN_EMAIL;
        
        const initialRole = isAdminEmail ? 'admin' : 'student';
        setRole(initialRole);
        
        const userDocRef = doc(db, 'users', fbUser.uid);
        
        unsubscribeProfile = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const userData = docSnap.data() as User;
            
            if (userData.isBlocked && userData.role !== 'admin') {
              signOut(auth);
              return;
            }
            
            // Stability: Use deep comparison to prevent infinite re-renders
            setUser(prev => {
              const nextUser = { ...userData, id: fbUser.uid };
              if (JSON.stringify(prev) === JSON.stringify(nextUser)) return prev;
              return nextUser;
            });
            
            if (userData.role) {
                setRole(userData.role as any);
            }
          } else {
            const newUser: User = {
              id: fbUser.uid,
              name: fbUser.displayName || (isAdminEmail ? 'Admin' : 'Student'),
              email: fbUser.email || '',
              points: 0,
              isBlocked: false,
              role: initialRole as any,
              avatarUrl: fbUser.photoURL || `https://picsum.photos/seed/${fbUser.uid}/200`,
              language: 'English'
            };
            setDoc(userDocRef, newUser).catch(() => {});
            setUser(newUser);
          }
          setIsLoading(false);
        }, (err) => {
          console.error("Auth snapshot error:", err);
          setIsLoading(false);
        });
      } else {
        setUser(null);
        setRole(null);
        setIsLoading(false);
        if (unsubscribeProfile) {
            unsubscribeProfile();
            unsubscribeProfile = null;
        }
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, [auth, db]);

  const login = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      return { 
        success: true, 
        message: 'Login successful!', 
        role: email.toLowerCase() === ADMIN_EMAIL ? 'admin' : 'student' 
      };
    } catch (error: any) {
      return { success: false, message: 'Invalid credentials. Please check your email and password.' };
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    try {
      const { user: fbUser } = await createUserWithEmailAndPassword(auth, email, pass);
      const initialRole = email.toLowerCase() === ADMIN_EMAIL ? 'admin' : 'student';
      
      const newUser: User = {
        id: fbUser.uid,
        name,
        email,
        points: 0,
        isBlocked: false,
        role: initialRole as any,
        avatarUrl: `https://picsum.photos/seed/${fbUser.uid}/200`,
        language: 'English'
      };

      await setDoc(doc(db, 'users', fbUser.uid), newUser);
      return { success: true, message: 'Registration successful!', role: initialRole };
    } catch (error: any) {
      return { success: false, message: error.message || 'Registration failed' };
    }
  };

  const logout = async () => {
    await signOut(auth);
    setUser(null);
    setRole(null);
    router.push('/login');
  };

  const updateUserPoints = (userId: string, points: number) => {
    if (!userId) return;
    const userRef = doc(db, 'users', userId);
    updateDocumentNonBlocking(userRef, { points: increment(points) });
  };

  const refreshUser = async () => {};

  return (
    <AuthContext.Provider value={{ 
      user, role, isAuthenticated: !!user, isLoading, login, register, logout, updateUserPoints, refreshUser 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) throw new Error('useAuth must be used within an AuthProvider');
  return context;
}
