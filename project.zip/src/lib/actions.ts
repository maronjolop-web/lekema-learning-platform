'use server';

import { revalidatePath } from 'next/cache';
import { 
    createLesson as dbCreateLesson,
    updateLesson as dbUpdateLesson,
    deleteLesson as dbDeleteLesson,
    createQuiz as dbCreateQuiz,
    updateQuiz as dbUpdateQuiz,
    deleteQuiz as dbDeleteQuiz,
    addQuestionToQuiz as dbAddQuestion,
    updateQuestionInQuiz as dbUpdateQuestion,
    deleteQuestionFromQuiz as dbDeleteQuestion,
    blockUser as dbBlockUser,
    unblockUser as dbUnblockUser,
    updateUser as dbUpdateUser
} from './data';

// Lesson Actions
export async function createLesson(formData: FormData) {
  const title = formData.get('title') as string;
  const description = formData.get('description') as string;
  const youtubeLink = formData.get('youtubeLink') as string;
  
  if (title && description && youtubeLink) {
    dbCreateLesson(title, description, youtubeLink);
    revalidatePath('/admin/lessons');
    revalidatePath('/dashboard/lessons');
    return { success: true, message: 'Lesson created successfully.' };
  }
  return { success: false, message: 'Missing required fields.' };
}

export async function updateLesson(formData: FormData) {
  const id = formData.get('id') as string;
  const title = formData.get('title') as string;
  const description = formData.get('description') as string;
  const youtubeLink = formData.get('youtubeLink') as string;

  if (id && title && description && youtubeLink) {
    dbUpdateLesson(id, title, description, youtubeLink);
    revalidatePath('/admin/lessons');
    revalidatePath(`/dashboard/lessons/${id}`);
    revalidatePath('/dashboard/lessons');
    return { success: true, message: 'Lesson updated successfully.' };
  }
  return { success: false, message: 'Missing required fields.' };
}

export async function deleteLesson(id: string) {
  if (id) {
    dbDeleteLesson(id);
    revalidatePath('/admin/lessons');
    revalidatePath('/dashboard/lessons');
    revalidatePath('/admin/quizzes'); // Also revalidate quizzes as they might be deleted
    return { success: true, message: 'Lesson deleted successfully.' };
  }
  return { success: false, message: 'Lesson ID is required.' };
}

// User Actions
export async function blockUser(id: string) {
    if(id) {
        dbBlockUser(id);
        revalidatePath('/admin/members');
        return { success: true, message: 'User blocked.' };
    }
    return { success: false, message: 'User ID is required.' };
}

export async function unblockUser(id: string) {
    if(id) {
        dbUnblockUser(id);
        revalidatePath('/admin/members');
        return { success: true, message: 'User unblocked.' };
    }
    return { success: false, message: 'User ID is required.' };
}

export async function updateUserProfile(formData: FormData) {
    const id = formData.get('id') as string;
    const name = formData.get('name') as string;
    const avatarUrl = formData.get('avatarUrl') as string;
    const language = formData.get('language') as string;
  
    if (id && name) {
      dbUpdateUser(id, { name, avatarUrl, language });
      revalidatePath('/admin/members');
      revalidatePath('/dashboard/members');
      revalidatePath('/admin/leaderboard');
      revalidatePath('/dashboard/leaderboard');
      return { success: true, message: 'Profile updated successfully.' };
    }
    return { success: false, message: 'Missing required fields.' };
}


// Quiz Actions
export async function createQuiz(formData: FormData) {
    const title = formData.get('title') as string;
    const lessonId = formData.get('lessonId') as string;
    
    if (title && lessonId) {
      dbCreateQuiz(lessonId, title);
      revalidatePath('/admin/quizzes');
      return { success: true, message: 'Quiz created successfully.' };
    }
    return { success: false, message: 'Missing required fields.' };
}

export async function updateQuiz(formData: FormData) {
    const id = formData.get('id') as string;
    const title = formData.get('title') as string;
    const lessonId = formData.get('lessonId') as string;
  
    if (id && title && lessonId) {
      dbUpdateQuiz(id, lessonId, title);
      revalidatePath('/admin/quizzes');
      return { success: true, message: 'Quiz updated successfully.' };
    }
    return { success: false, message: 'Missing required fields.' };
}
  
export async function deleteQuiz(id: string) {
    if (id) {
      dbDeleteQuiz(id);
      revalidatePath('/admin/quizzes');
      return { success: true, message: 'Quiz deleted successfully.' };
    }
    return { success: false, message: 'Quiz ID is required.' };
}

// Quiz Question Actions
export async function addQuestion(quizId: string, formData: FormData) {
    const question = formData.get('question') as string;
    const choices = formData.getAll('choices') as string[];
    const correctAnswer = formData.get('correctAnswer') as string;
    const points = parseInt(formData.get('points') as string, 10);

    if (quizId && question && choices.length >= 2 && correctAnswer && points) {
        dbAddQuestion(quizId, { question, choices, correctAnswer, points });
        revalidatePath(`/admin/quizzes`);
        return { success: true, message: 'Question added.' };
    }
    return { success: false, message: 'Missing fields for question.' };
}

export async function updateQuestion(quizId: string, questionId: string, formData: FormData) {
    const question = formData.get('question') as string;
    const choices = formData.getAll('choices') as string[];
    const correctAnswer = formData.get('correctAnswer') as string;
    const points = parseInt(formData.get('points') as string, 10);

    if (quizId && questionId && question && choices.length >= 2 && correctAnswer && points) {
        dbUpdateQuestion(quizId, questionId, { question, choices, correctAnswer, points });
        revalidatePath(`/admin/quizzes`);
        return { success: true, message: 'Question updated.' };
    }
    return { success: false, message: 'Missing fields for question.' };
}

export async function deleteQuestion(quizId: string, questionId: string) {
    if (quizId && questionId) {
        dbDeleteQuestion(quizId, questionId);
        revalidatePath(`/admin/quizzes`);
        return { success: true, message: 'Question deleted.' };
    }
    return { success: false, message: 'IDs are required.' };
}
