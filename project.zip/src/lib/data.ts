import type { User, Lesson, Quiz } from './definitions';
import { PlaceHolderImages } from './placeholder-images';

let users: User[] = [
  { id: '1', name: 'Admin User', email: 'lekema@gmail.com', password: 'LeKeMa2026', points: 0, isBlocked: false, role: 'admin', avatarUrl: PlaceHolderImages[0].imageUrl, language: 'English' },
  { id: '2', name: 'Alice Johnson', email: 'alice@example.com', password: 'password123', points: 150, isBlocked: false, role: 'student', avatarUrl: PlaceHolderImages[1].imageUrl, language: 'English' },
  { id: '3', name: 'Bob Williams', email: 'bob@example.com', password: 'password123', points: 120, isBlocked: false, role: 'student', avatarUrl: PlaceHolderImages[2].imageUrl, language: 'English' },
  { id: '4', name: 'Charlie Brown', email: 'charlie@example.com', password: 'password123', points: 180, isBlocked: true, role: 'student', avatarUrl: PlaceHolderImages[3].imageUrl, language: 'English' },
  { id: '5', name: 'Diana Prince', email: 'diana@example.com', password: 'password123', points: 200, isBlocked: false, role: 'student', avatarUrl: PlaceHolderImages[4].imageUrl, language: 'English' },
];

let lessons: Lesson[] = [
  {
    id: '1',
    title: 'Introduction to React Hooks',
    description: 'Learn the basics of React Hooks, including useState, useEffect, and useContext, to manage state and side effects in your functional components.',
    youtubeLink: 'https://www.youtube.com/watch?v=TNhaISOUy6Q'
  },
  {
    id: '2',
    title: 'Advanced Tailwind CSS',
    description: 'Dive deep into Tailwind CSS configuration, custom plugins, and performance optimization techniques for a professional workflow.',
    youtubeLink: 'https://www.youtube.com/watch?v=lCxcTsOHrjo'
  },
  {
    id: '3',
    title: 'Next.js App Router Explained',
    description: 'Understand the new App Router in Next.js, including layouts, server components, and data fetching strategies.',
    youtubeLink: 'https://www.youtube.com/watch?v=sUKptz_sV2c'
  }
];

let quizzes: Quiz[] = [
  {
    id: '1',
    lessonId: '1',
    title: 'React Hooks Basics',
    questions: [
      { id: 'q1', question: 'What does `useState` return?', choices: ['A single value', 'An array with a value and a function', 'An object', 'A function'], correctAnswer: 'An array with a value and a function', points: 10 },
      { id: 'q2', question: 'When does `useEffect` run by default?', choices: ['Only once', 'On every render', 'When its dependencies change', 'Never'], correctAnswer: 'On every render', points: 10 },
    ]
  },
  {
    id: '2',
    lessonId: '2',
    title: 'Tailwind CSS Fundamentals',
    questions: [
      { id: 'q3', question: 'How do you apply a hover effect in Tailwind?', choices: ['hover->', 'hover:', 'onHover=', 'hover-'], correctAnswer: 'hover:', points: 10 },
      { id: 'q4', question: 'What file is used to configure Tailwind?', choices: ['tailwind.js', 'package.json', 'tailwind.config.ts', 'styles.css'], correctAnswer: 'tailwind.config.ts', points: 10 },
      { id: 'q5', question: 'What does the `@apply` directive do?', choices: ['Imports a CSS file', 'Applies custom styles', 'Inlines utility classes into a custom CSS class', 'Nothing'], correctAnswer: 'Inlines utility classes into a custom CSS class', points: 15 },
    ]
  }
];

// User Functions
export const getUsers = () => users;
export const getStudents = () => users.filter(u => u.role === 'student');
export const getUserById = (id: string) => users.find(u => u.id === id);
export const getUserByEmail = (email: string) => users.find(u => u.email.toLowerCase() === email.toLowerCase());
export const createUser = (name: string, email: string, password_raw: string): User | null => {
  const newUser: User = {
    id: String(users.length + 1),
    name,
    email,
    password: password_raw,
    points: 0,
    isBlocked: false,
    role: 'student',
    avatarUrl: PlaceHolderImages[Math.floor(Math.random() * PlaceHolderImages.length)].imageUrl,
    language: 'English',
  };
  users.push(newUser);
  return newUser;
};
export const blockUser = (id: string) => {
  const userIndex = users.findIndex(u => u.id === id);
  if (userIndex !== -1) {
    users[userIndex].isBlocked = true;
  }
  return users[userIndex];
};
export const unblockUser = (id: string) => {
  const userIndex = users.findIndex(u => u.id === id);
  if (userIndex !== -1) {
    users[userIndex].isBlocked = false;
  }
  return users[userIndex];
};
export const updateUser = (id: string, data: { name: string; avatarUrl: string; language: string; }) => {
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex !== -1) {
        users[userIndex] = { 
            ...users[userIndex],
            ...data
        };
        return users[userIndex];
    }
    return null;
};

// Lesson Functions
export const getLessons = () => lessons;
export const getLessonById = (id: string) => lessons.find(l => l.id === id);
export const createLesson = (title: string, description: string, youtubeLink: string) => {
  const newLesson: Lesson = { id: String(lessons.length + 1), title, description, youtubeLink };
  lessons.push(newLesson);
  return newLesson;
};
export const updateLesson = (id: string, title: string, description: string, youtubeLink: string) => {
  const lessonIndex = lessons.findIndex(l => l.id === id);
  if (lessonIndex !== -1) {
    lessons[lessonIndex] = { ...lessons[lessonIndex], title, description, youtubeLink };
    return lessons[lessonIndex];
  }
  return null;
};
export const deleteLesson = (id: string) => {
  lessons = lessons.filter(l => l.id !== id);
  quizzes = quizzes.filter(q => q.lessonId !== id); // Also delete associated quizzes
};


// Quiz Functions
export const getQuizzes = () => quizzes;
export const getQuizById = (id: string) => quizzes.find(q => q.id === id);
export const getQuizzesByLessonId = (lessonId: string) => quizzes.filter(q => q.lessonId === lessonId);
export const createQuiz = (lessonId: string, title: string) => {
  const newQuiz: Quiz = { id: String(quizzes.length + 1), lessonId, title, questions: [] };
  quizzes.push(newQuiz);
  return newQuiz;
};
export const updateQuiz = (id: string, lessonId: string, title: string) => {
    const quizIndex = quizzes.findIndex(q => q.id === id);
    if (quizIndex !== -1) {
        quizzes[quizIndex] = { ...quizzes[quizIndex], lessonId, title };
        return quizzes[quizIndex];
    }
    return null;
}
export const deleteQuiz = (id: string) => {
  quizzes = quizzes.filter(q => q.id !== id);
};
export const addQuestionToQuiz = (quizId: string, questionData: Omit<Quiz['questions'][0], 'id'>) => {
  const quizIndex = quizzes.findIndex(q => q.id === quizId);
  if(quizIndex !== -1) {
    const newQuestion = { ...questionData, id: `q${Date.now()}` };
    quizzes[quizIndex].questions.push(newQuestion);
    return newQuestion;
  }
  return null;
}
export const updateQuestionInQuiz = (quizId: string, questionId: string, questionData: Omit<Quiz['questions'][0], 'id'>) => {
    const quizIndex = quizzes.findIndex(q => q.id === quizId);
    if(quizIndex !== -1) {
        const questionIndex = quizzes[quizIndex].questions.findIndex(q => q.id === questionId);
        if(questionIndex !== -1) {
            quizzes[quizIndex].questions[questionIndex] = { ...quizzes[quizIndex].questions[questionIndex], ...questionData };
            return quizzes[quizIndex].questions[questionIndex];
        }
    }
    return null;
}
export const deleteQuestionFromQuiz = (quizId: string, questionId: string) => {
    const quizIndex = quizzes.findIndex(q => q.id === quizId);
    if(quizIndex !== -1) {
        quizzes[quizIndex].questions = quizzes[quizIndex].questions.filter(q => q.id !== questionId);
    }
}
