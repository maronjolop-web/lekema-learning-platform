export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  points: number;
  isBlocked: boolean;
  role: 'admin' | 'student';
  avatarUrl: string;
  language: string;
  lastActive?: string;
  currentAction?: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  youtubeLink: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  choices: string[];
  correctAnswer: string;
  points: number;
}

export type QuizDifficulty = 'Easy' | 'Normal' | 'Hard';

export interface Quiz {
  id: string;
  lessonId: string;
  title: string;
  difficulty: QuizDifficulty;
  questions: QuizQuestion[];
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  createdAt: any;
}

export interface Conversation {
  id: string;
  participants: string[];
  lastMessage: string;
  updatedAt: any;
}

export interface Announcement {
  id: string;
  text: string;
  authorName: string;
  createdAt: any;
}

export type NotificationType = 'lesson' | 'quiz' | 'message' | 'announcement';

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: NotificationType;
  createdAt: any;
  read: boolean;
}
