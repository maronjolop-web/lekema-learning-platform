
'use client';

import { collection, serverTimestamp, Firestore } from 'firebase/firestore';
import { addDocumentNonBlocking } from './non-blocking-updates';
import { NotificationType } from '@/lib/definitions';

export interface CreateNotificationInput {
  userId: string; // User ID or 'all'
  title: string;
  body: string;
  type: NotificationType;
}

/**
 * Creates a notification in Firestore.
 */
export function sendNotification(db: Firestore, input: CreateNotificationInput) {
  const notifRef = collection(db, 'notifications');
  addDocumentNonBlocking(notifRef, {
    ...input,
    createdAt: serverTimestamp(),
    read: false,
  });
}
