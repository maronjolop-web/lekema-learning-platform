export const firebaseConfig = {
  "projectId": "studio-3299352105-c0530",
  "appId": "1:197229881628:web:06c4b1a200d6045813f2d9",
  "apiKey": "AIzaSyCudy1yqu_CxKg6W-k47yG-AiUqGrCs_V0",
  "authDomain": "studio-3299352105-c0530.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "197229881628"
};
