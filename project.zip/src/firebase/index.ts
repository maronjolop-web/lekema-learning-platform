'use client';

import { firebaseConfig } from '@/firebase/config';
import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  initializeFirestore, 
  memoryLocalCache, 
  clearIndexedDbPersistence 
} from 'firebase/firestore';

/**
 * Initializes Firebase with a focus on stability and storage resilience.
 * Uses memoryLocalCache to resolve [code=unavailable] and QuotaExceededError.
 */
export function initializeFirebase() {
  const existingApp = getApps()[0];
  const app = existingApp || initializeApp(firebaseConfig);

  // Definitive fix for connectivity/storage lockups: Memory-Only Cache
  let firestore;
  try {
    firestore = initializeFirestore(app, {
      localCache: memoryLocalCache(),
    });
  } catch (e) {
    firestore = getFirestore(app);
  }

  const sdks = {
    firebaseApp: app,
    auth: getAuth(app),
    firestore: firestore
  };

  // Cleanup legacy persistence data if present
  if (typeof window !== 'undefined') {
    clearIndexedDbPersistence(sdks.firestore).catch(() => {});
  }

  return sdks;
}

export * from './provider';
export * from './client-provider';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './non-blocking-updates';
export * from './non-blocking-login';
export * from './errors';
export * from './error-emitter';