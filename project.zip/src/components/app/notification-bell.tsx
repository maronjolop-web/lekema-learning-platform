
'use client';

import React, { useEffect, useState } from 'react';
import { Bell, Loader2, Check } from 'lucide-react';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { useFirestore, useCollection, useMemoFirebase, useAuth as useFirebase } from '@/firebase';
import { collection, query, where, orderBy, limit, doc } from 'firebase/firestore';
import { updateDocumentNonBlocking } from '@/firebase';
import { AppNotification } from '@/lib/definitions';
import { formatDistanceToNow } from 'date-fns';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export default function NotificationBell() {
  const db = useFirestore();
  const { user } = useFirebase();
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermission(window.Notification.permission);
    }
  }, []);

  const requestPermission = () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      window.Notification.requestPermission().then(setPermission);
    }
  };

  const notificationsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(db, 'notifications'),
      where('userId', 'in', [user.uid, 'all']),
      orderBy('createdAt', 'desc'),
      limit(20)
    );
  }, [db, user]);

  const { data: notifications, isLoading } = useCollection<AppNotification>(notificationsQuery);
  const unreadCount = notifications?.filter(n => !n.read && n.userId === user?.uid).length || 0;

  // Browser Push Logic
  useEffect(() => {
    if (!notifications || notifications.length === 0) return;
    
    const latest = notifications[0];
    const isRecent = latest.createdAt?.seconds && (Date.now() / 1000 - latest.createdAt.seconds < 30);
    
    if (isRecent && !latest.read && permission === 'granted' && typeof window !== 'undefined' && 'Notification' in window) {
      new window.Notification(latest.title, {
        body: latest.body,
        icon: 'https://iili.io/qJ8YSz7.md.png'
      });
    }
  }, [notifications, permission]);

  const markAsRead = (id: string) => {
    const ref = doc(db, 'notifications', id);
    updateDocumentNonBlocking(ref, { read: true });
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative h-10 w-10 rounded-full">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-destructive text-white border-2 border-background animate-in zoom-in">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 overflow-hidden shadow-2xl border-2" align="end">
        <div className="bg-primary/5 p-4 border-b flex items-center justify-between">
          <div>
            <h3 className="font-headline font-bold text-primary">Notifications</h3>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-black">Latest updates</p>
          </div>
          {permission !== 'granted' && (
            <Button variant="outline" size="sm" className="text-[9px] h-6 px-2" onClick={requestPermission}>
              Enable Push
            </Button>
          )}
        </div>
        
        <ScrollArea className="h-[350px]">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : notifications && notifications.length > 0 ? (
            <div className="divide-y divide-border">
              {notifications.map((notif) => (
                <div 
                  key={notif.id} 
                  className={cn(
                    "p-4 transition-colors hover:bg-muted/30 relative group",
                    !notif.read && notif.userId !== 'all' ? "bg-primary/5" : ""
                  )}
                >
                  <div className="flex justify-between items-start gap-2 mb-1">
                    <span className="text-xs font-bold leading-tight">{notif.title}</span>
                    {!notif.read && notif.userId !== 'all' && (
                      <button 
                        onClick={() => markAsRead(notif.id)}
                        className="text-primary hover:text-primary/70 transition-colors"
                      >
                        <Check className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{notif.body}</p>
                  <span className="text-[10px] text-muted-foreground/60 font-medium">
                    {notif.createdAt?.seconds ? formatDistanceToNow(new Date(notif.createdAt.seconds * 1000)) + ' ago' : 'Just now'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center text-muted-foreground">
              <Bell className="h-10 w-10 opacity-20 mb-2" />
              <p className="text-sm">No notifications yet.</p>
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
