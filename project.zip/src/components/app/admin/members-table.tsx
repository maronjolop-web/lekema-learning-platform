
'use client';

import { useState } from 'react';
import { User } from '@/lib/definitions';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MessageSquare, MoreHorizontal, ShieldAlert, ShieldCheck, User as UserIcon, Trash2, Loader2 } from 'lucide-react';
import { useFirestore, useAuth as useFirebaseUser } from '@/firebase';
import { doc } from 'firebase/firestore';
import { updateDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase';
import ProfileForm from '../profile-form';
import { cn } from '@/lib/utils';
import ChatDialog from '../chat-dialog';

interface MembersTableProps {
  students: User[];
  showRole?: boolean;
}

export default function MembersTable({ students, showRole = false }: MembersTableProps) {
  const { toast } = useToast();
  const db = useFirestore();
  const { user: currentUser } = useFirebaseUser();
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleBlockToggle = (id: string, isBlocked: boolean, role: string) => {
    if (role === 'admin') {
        toast({
            title: "Restriction Error",
            description: "Admin accounts cannot be blocked.",
            variant: "destructive"
        });
        return;
    }

    const userRef = doc(db, 'users', id);
    updateDocumentNonBlocking(userRef, { isBlocked: !isBlocked });
    
    toast({ 
      title: isBlocked ? 'Access Restored' : 'Access Restricted', 
      description: `User status successfully updated.`,
    });
  };

  const handleDeleteUser = () => {
    if (!userToDelete) return;
    
    setIsDeleting(true);
    const userRef = doc(db, 'users', userToDelete.id);
    
    try {
      deleteDocumentNonBlocking(userRef);
      toast({
        title: "Account Deleted",
        description: `${userToDelete.name}'s account has been permanently removed.`,
      });
      setUserToDelete(null);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete account. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const getInitials = (name: string) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name.substring(0, 2);
  };

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Identity</TableHead>
            {showRole && <TableHead>Role</TableHead>}
            <TableHead>Points</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {students.map((student) => (
            <TableRow key={student.id} className="hover:bg-muted/30">
              <TableCell>
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 border border-border">
                    <AvatarImage src={student.avatarUrl} alt={student.name} />
                    <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-bold text-sm">{student.name}</span>
                    <span className="text-[10px] text-muted-foreground uppercase tracking-tight">{student.email}</span>
                  </div>
                </div>
              </TableCell>
              {showRole && (
                <TableCell>
                    <span className={cn(
                        "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-sm border",
                        student.role === 'admin' ? "bg-accent/10 text-accent border-accent/20" : "bg-primary/10 text-primary border-primary/20"
                    )}>
                        {student.role}
                    </span>
                </TableCell>
              )}
              <TableCell className="font-bold text-primary tabular-nums">
                {(student.points || 0).toLocaleString()}
              </TableCell>
              <TableCell>
                <Badge variant={student.isBlocked ? 'destructive' : 'outline'} className="capitalize">
                  {student.isBlocked ? 'Blocked' : 'Active'}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-2">
                  <ChatDialog 
                    targetUser={student} 
                    trigger={
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-primary">
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    } 
                  />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="icon" variant="ghost" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-[180px]">
                      <DropdownMenuLabel>Member Commands</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      
                      <ProfileForm user={student}>
                        <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                          <UserIcon className="mr-2 h-4 w-4" /> View Details
                        </DropdownMenuItem>
                      </ProfileForm>

                      {student.role !== 'admin' && (
                        <>
                          <DropdownMenuItem
                              onClick={() => handleBlockToggle(student.id, student.isBlocked, student.role)}
                              className={student.isBlocked ? "text-primary" : "text-amber-600"}
                          >
                              {student.isBlocked ? (
                              <><ShieldCheck className="mr-2 h-4 w-4" /> Restore Access</>
                              ) : (
                              <><ShieldAlert className="mr-2 h-4 w-4" /> Restrict Access</>
                              )}
                          </DropdownMenuItem>
                          
                          <DropdownMenuSeparator />
                          
                          <DropdownMenuItem 
                            onClick={() => setUserToDelete(student)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete Account
                          </DropdownMenuItem>
                        </>
                      )}
                      
                      {student.role === 'admin' && student.id !== currentUser?.uid && (
                        <DropdownMenuItem disabled className="text-muted-foreground">
                          <ShieldAlert className="mr-2 h-4 w-4" /> Admin Protected
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {students.length === 0 && (
            <TableRow>
              <TableCell colSpan={showRole ? 5 : 4} className="text-center py-10 text-muted-foreground">
                No matching records found in the directory.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <AlertDialog open={!!userToDelete} onOpenChange={(open) => !open && setUserToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Trash2 className="h-5 w-5 text-destructive" />
              Confirm Permanent Deletion
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{userToDelete?.name}</strong>? This action will permanently remove their profile, points, and all associated data. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button 
              variant="destructive" 
              onClick={handleDeleteUser} 
              disabled={isDeleting}
              className="gap-2"
            >
              {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
              Delete Permanently
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
