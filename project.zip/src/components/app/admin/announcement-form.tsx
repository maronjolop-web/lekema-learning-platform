'use client';

import React, { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Announcement } from '@/lib/definitions';
import { useFirestore } from '@/firebase';
import { doc, collection, serverTimestamp } from 'firebase/firestore';
import { setDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { sendNotification } from '@/firebase/notifications';
import { useAuth } from '@/lib/auth';
import { Pencil, Trash2, PlusCircle } from 'lucide-react';

const formSchema = z.object({
  text: z.string().min(5, { message: 'Note must be at least 5 characters.' }),
});

interface AnnouncementFormProps {
  children?: React.ReactNode;
  announcement?: Announcement;
}

export default function AnnouncementForm({ children, announcement }: AnnouncementFormProps) {
  const { toast } = useToast();
  const db = useFirestore();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      text: announcement?.text || '',
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (!user) return;
    try {
      if (announcement) {
        const docRef = doc(db, 'announcements', announcement.id);
        setDocumentNonBlocking(docRef, values, { merge: true });
        toast({ title: 'Success', description: 'Activity note updated.' });
      } else {
        const colRef = collection(db, 'announcements');
        addDocumentNonBlocking(colRef, {
          ...values,
          authorName: user.name,
          createdAt: serverTimestamp(),
        });
        
        sendNotification(db, {
          userId: 'all',
          title: 'New Public Update',
          body: values.text,
          type: 'announcement'
        });

        toast({ title: 'Success', description: 'Activity note posted.' });
        form.reset();
      }
      setOpen(false);
    } catch (error: any) {
      console.error("Announcement update failed:", error);
    }
  };

  const handleDelete = () => {
    if(!announcement) return;
    const docRef = doc(db, 'announcements', announcement.id);
    deleteDocumentNonBlocking(docRef);
    toast({ title: 'Deleted', description: 'Activity note removed.' });
    setDeleteDialogOpen(false);
    setOpen(false);
  }

  return (
    <>
    <Dialog open={open} onOpenChange={setOpen}>
      {children ? (
          <DialogTrigger asChild>{children}</DialogTrigger>
      ) : (
          <Button variant="outline" size="sm" className="gap-2">
              <Pencil className="h-4 w-4" /> Edit Note
          </Button>
      )}
      <DialogContent className="sm:max-w-[425px] panel bg-card">
        <DialogHeader>
          <DialogTitle className="font-headline text-primary">
            {announcement ? 'Edit Activity Note' : 'Create Activity Note'}
          </DialogTitle>
          <DialogDescription>
            Post a public update to all members of LeKeMa.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="text"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Update Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="What's happening?" 
                      {...field} 
                      className="min-h-[120px] bg-background/50 border-2"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="flex flex-col sm:flex-row gap-3">
              {announcement && (
                  <Button type="button" variant="destructive" onClick={() => setDeleteDialogOpen(true)} className="sm:mr-auto">
                      <Trash2 className="h-4 w-4 mr-2" /> Delete
                  </Button>
              )}
              <Button type="submit" className="premium-btn">
                {announcement ? 'Save Changes' : 'Post Note'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>

     <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="panel bg-card border-destructive">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive font-headline">Confirm Deletion</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this public activity note? This action is permanent and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={handleDelete}>
              Delete Permanently
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}