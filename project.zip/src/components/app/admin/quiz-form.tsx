
'use client';

import React, { useState, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, useFieldArray } from 'react-hook-form';
import * as z from 'zod';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, Trash, X, AlertTriangle, Loader2 } from 'lucide-react';
import { Quiz, Lesson, QuizQuestion } from '@/lib/definitions';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useFirestore } from '@/firebase';
import { doc, collection } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { updateDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { sendNotification } from '@/firebase/notifications';

const quizFormSchema = z.object({
  title: z.string().min(3, { message: 'Title must be at least 3 characters.' }),
  lessonId: z.string({ required_error: "Please select a lesson." }),
  difficulty: z.enum(['Easy', 'Normal', 'Hard']),
});

const questionFormSchema = z.object({
    question: z.string().min(5, "Question is too short."),
    choices: z.array(z.string().min(1, "Choice cannot be empty.")).optional(),
    correctAnswer: z.string().min(1, "A correct answer must be provided."),
    points: z.coerce.number().min(1, "Points must be at least 1.")
});

interface QuizFormProps {
  children: React.ReactNode;
  quiz?: Quiz;
  lessons: Lesson[];
}

export default function QuizForm({ children, quiz, lessons }: QuizFormProps) {
  const { toast } = useToast();
  const db = useFirestore();
  const [open, setOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<QuizQuestion | null | {}>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const form = useForm<z.infer<typeof quizFormSchema>>({
    resolver: zodResolver(quizFormSchema),
    defaultValues: {
      title: quiz?.title || '',
      lessonId: quiz?.lessonId || '',
      difficulty: quiz?.difficulty || 'Normal',
    },
  });
  
  const currentDifficulty = form.watch('difficulty');

  const questionForm = useForm<z.infer<typeof questionFormSchema>>({
    resolver: zodResolver(questionFormSchema),
    defaultValues: {
        question: '',
        choices: currentDifficulty === 'Easy' ? ['True', 'False'] : currentDifficulty === 'Hard' ? [] : ['', ''],
        correctAnswer: '',
        points: 10
    }
  });

  const { fields, append, remove } = useFieldArray({
    control: questionForm.control,
    name: "choices"
  });

  useEffect(() => {
    if (editingQuestion && !('id' in editingQuestion)) {
      if (currentDifficulty === 'Easy') {
        questionForm.reset({ ...questionForm.getValues(), choices: ['True', 'False'] });
      } else if (currentDifficulty === 'Hard') {
        questionForm.reset({ ...questionForm.getValues(), choices: [] });
      } else {
        questionForm.reset({ ...questionForm.getValues(), choices: ['', ''] });
      }
    }
  }, [currentDifficulty, editingQuestion, questionForm]);

  const onQuizSubmit = (values: z.infer<typeof quizFormSchema>) => {
    try {
      if (quiz) {
        const docRef = doc(db, 'quizzes', quiz.id);
        updateDocumentNonBlocking(docRef, values);

        sendNotification(db, {
          userId: 'all',
          title: 'Quiz Updated',
          body: `The quiz "${values.title}" has been updated. Get ready for a challenge!`,
          type: 'quiz'
        });

        toast({ title: 'Success', description: 'Quiz updated successfully.' });
      } else {
        const colRef = collection(db, 'quizzes');
        addDocumentNonBlocking(colRef, { ...values, questions: [] });

        sendNotification(db, {
          userId: 'all',
          title: 'New Quiz Available',
          body: `A new quiz "${values.title}" has been released!`,
          type: 'quiz'
        });

        toast({ title: 'Success', description: 'Quiz created successfully.' });
        setOpen(false);
      }
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: quiz ? `quizzes/${quiz.id}` : 'quizzes',
        operation: quiz ? 'update' : 'create',
        requestResourceData: values,
      }));
    }
  };

  const onQuestionSubmit = (values: z.infer<typeof questionFormSchema>) => {
    if(!quiz) return;
    
    try {
      const isEditing = editingQuestion && 'id' in editingQuestion;
      const quizRef = doc(db, 'quizzes', quiz.id);
      
      let updatedQuestions = [...(quiz.questions || [])];
      
      let finalChoices = values.choices || [];
      if (currentDifficulty === 'Easy') finalChoices = ['True', 'False'];
      if (currentDifficulty === 'Hard') finalChoices = [];

      const questionData = {
        ...values,
        choices: finalChoices,
      };

      if (isEditing) {
        const index = updatedQuestions.findIndex(q => q.id === (editingQuestion as QuizQuestion).id);
        if (index !== -1) {
          updatedQuestions[index] = { ...questionData, id: (editingQuestion as QuizQuestion).id };
        }
      } else {
        updatedQuestions.push({ ...questionData, id: `q${Date.now()}` });
      }

      updateDocumentNonBlocking(quizRef, { questions: updatedQuestions });
      
      toast({ title: 'Success', description: isEditing ? 'Question updated.' : 'Question added.' });
      setEditingQuestion(null);
      questionForm.reset({ 
        question: '', 
        choices: currentDifficulty === 'Easy' ? ['True', 'False'] : currentDifficulty === 'Hard' ? [] : ['', ''], 
        correctAnswer: '', 
        points: 10 
      });
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `quizzes/${quiz.id}`,
        operation: 'update',
      }));
    }
  }

  const handleEditQuestion = (q: QuizQuestion) => {
    setEditingQuestion(q);
    questionForm.reset({
        question: q.question,
        choices: q.choices,
        correctAnswer: q.correctAnswer,
        points: q.points
    });
  }

  const handleDeleteQuestion = (questionId: string) => {
    if(!quiz) return;
    try {
      const quizRef = doc(db, 'quizzes', quiz.id);
      const updatedQuestions = quiz.questions.filter(q => q.id !== questionId);
      updateDocumentNonBlocking(quizRef, { questions: updatedQuestions });
      toast({ title: 'Success', description: 'Question deleted.' });
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `quizzes/${quiz.id}`,
        operation: 'update',
      }));
    }
  }

  const handleConfirmDeleteQuiz = async () => {
    if (!quiz) return;
    setIsDeleting(true);
    try {
      const docRef = doc(db, 'quizzes', quiz.id);
      deleteDocumentNonBlocking(docRef);
      
      toast({ title: 'Deleted', description: 'The quiz has been removed successfully.' });
      setShowDeleteConfirm(false);
      setOpen(false);
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `quizzes/${quiz.id}`,
        operation: 'delete',
      }));
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>{children}</DialogTrigger>
        <DialogContent className="max-w-4xl h-[90vh]">
          <DialogHeader>
            <DialogTitle>{quiz ? 'Manage Quiz' : 'Create Quiz'}</DialogTitle>
            <DialogDescription>
              Difficulty: <strong>{currentDifficulty}</strong>. {quiz ? 'Manage the quiz details and its questions.' : 'Create a new quiz and add questions.'}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-full -mx-6 px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-4">
              <div>
                  <h3 className="font-headline text-lg mb-4 border-b pb-2">Quiz Details</h3>
                  <Form {...form}>
                      <form onSubmit={form.handleSubmit(onQuizSubmit)} className="space-y-4">
                          <FormField control={form.control} name="title" render={({ field }) => (
                               <FormItem>
                               <FormLabel>Title</FormLabel>
                               <FormControl><Input {...field} /></FormControl>
                               <FormMessage />
                             </FormItem>
                          )}/>
                          <FormField control={form.control} name="lessonId" render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Lesson Association</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                      <FormControl><SelectTrigger><SelectValue placeholder="Select which lesson this quiz belongs to" /></SelectTrigger></FormControl>
                                      <SelectContent>
                                          {lessons.map(l => <SelectItem key={l.id} value={l.id}>{l.title}</SelectItem>)}
                                      </SelectContent>
                                  </Select>
                                  <FormMessage />
                              </FormItem>
                          )}/>
                          <FormField control={form.control} name="difficulty" render={({ field }) => (
                              <FormItem>
                                  <FormLabel>Difficulty Mode</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                      <FormControl><SelectTrigger><SelectValue placeholder="Select mode" /></SelectTrigger></FormControl>
                                      <SelectContent>
                                          <SelectItem value="Easy">Easy (True/False)</SelectItem>
                                          <SelectItem value="Normal">Normal (Multiple Choice)</SelectItem>
                                          <SelectItem value="Hard">Hard (Identification)</SelectItem>
                                      </SelectContent>
                                  </Select>
                                  <FormMessage />
                              </FormItem>
                          )}/>
                           <div className="flex flex-col gap-2">
                            <Button type="submit" className="w-full">
                                {quiz ? "Update Quiz Details" : "Create New Quiz"}
                            </Button>
                            {quiz && (
                              <Button 
                                type="button" 
                                variant="destructive" 
                                className="w-full"
                                onClick={() => setShowDeleteConfirm(true)}
                              >
                                <Trash className="mr-2 h-4 w-4" /> Delete Entire Quiz
                              </Button>
                            )}
                          </div>
                      </form>
                  </Form>
                  {quiz && (
                      <div className="mt-8">
                          <h3 className="font-headline text-lg mb-4 border-b pb-2">Questions</h3>
                          <div className="space-y-2">
                              {quiz.questions?.map(q => (
                                  <div key={q.id} className="flex items-center justify-between p-2 rounded-md bg-muted">
                                      <p className="truncate flex-1 font-medium">{q.question}</p>
                                      <div className="flex items-center gap-1">
                                          <Button size="sm" variant="ghost" onClick={() => handleEditQuestion(q)}>Edit</Button>
                                          <Button size="icon" variant="ghost" className="text-destructive" onClick={() => handleDeleteQuestion(q.id)}><Trash className="h-4 w-4"/></Button>
                                      </div>
                                  </div>
                              ))}
                              {(!quiz.questions || quiz.questions.length === 0) && <p className="text-sm text-center text-muted-foreground py-4">No questions added yet.</p>}
                          </div>
                           <Button variant="outline" size="sm" className="mt-4 w-full" onClick={() => setEditingQuestion({})}>
                              <PlusCircle className="mr-2 h-4 w-4" /> Add New Question
                           </Button>
                      </div>
                  )}
              </div>
              { (quiz || editingQuestion) && (
              <div>
                   <h3 className="font-headline text-lg mb-4 border-b pb-2">{editingQuestion && 'id' in editingQuestion ? 'Edit Question' : 'Add Question'}</h3>
                   {editingQuestion ? (
                      <Form {...questionForm}>
                          <form onSubmit={questionForm.handleSubmit(onQuestionSubmit)} className="space-y-4">
                              <FormField control={questionForm.control} name="question" render={({ field }) => (
                                  <FormItem><FormLabel>Question Text</FormLabel><FormControl><Input placeholder="Enter your question here..." {...field} /></FormControl><FormMessage /></FormItem>
                              )}/>
                              
                              {currentDifficulty === 'Normal' && (
                                  <div>
                                      <Label>Choices</Label>
                                      <div className="space-y-2 mt-2">
                                      {fields.map((field, index) => (
                                          <div key={field.id} className="flex items-center gap-2">
                                              <FormField control={questionForm.control} name={`choices.${index}`} render={({ field }) => (
                                                  <FormItem className="flex-1"><FormControl><Input placeholder={`Choice ${index + 1}`} {...field} /></FormControl><FormMessage /></FormItem>
                                              )}/>
                                              <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}><X className="h-4 w-4" /></Button>
                                          </div>
                                      ))}
                                      </div>
                                      <Button type="button" size="sm" variant="outline" className="mt-2 w-full" onClick={() => append('')}>Add Choice</Button>
                                  </div>
                              )}

                              {currentDifficulty === 'Easy' && (
                                  <FormField control={questionForm.control} name="correctAnswer" render={({ field }) => (
                                      <FormItem>
                                          <FormLabel>Correct Answer</FormLabel>
                                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                                              <FormControl><SelectTrigger><SelectValue placeholder="Select correct answer" /></SelectTrigger></FormControl>
                                              <SelectContent>
                                                  <SelectItem value="True">True</SelectItem>
                                                  <SelectItem value="False">False</SelectItem>
                                              </SelectContent>
                                          </Select>
                                          <FormMessage />
                                      </FormItem>
                                  )}/>
                              )}

                              {currentDifficulty === 'Normal' && (
                                  <FormField control={questionForm.control} name="correctAnswer" render={({ field }) => (
                                      <FormItem>
                                          <FormLabel>Correct Answer</FormLabel>
                                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                                              <FormControl><SelectTrigger><SelectValue placeholder="Select from choices above" /></SelectTrigger></FormControl>
                                              <SelectContent>
                                                  {questionForm.watch('choices')?.map((c, i) => c && <SelectItem key={i} value={c}>{c}</SelectItem>)}
                                              </SelectContent>
                                          </Select>
                                          <FormMessage />
                                      </FormItem>
                                  )}/>
                              )}

                              {currentDifficulty === 'Hard' && (
                                  <FormField control={questionForm.control} name="correctAnswer" render={({ field }) => (
                                      <FormItem>
                                          <FormLabel>Correct Answer (Identification)</FormLabel>
                                          <FormControl><Input placeholder="Enter the exact answer expected..." {...field} /></FormControl>
                                          <FormMessage />
                                      </FormItem>
                                  )}/>
                              )}

                               <FormField control={questionForm.control} name="points" render={({ field }) => (
                                  <FormItem><FormLabel>Points Value</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                              )}/>
                              <div className="flex gap-2">
                                  <Button type="submit" className="flex-1">
                                      {editingQuestion && 'id' in editingQuestion ? 'Update Question' : 'Add Question'}
                                  </Button>
                                  <Button type="button" variant="ghost" onClick={() => setEditingQuestion(null)}>Cancel</Button>
                              </div>
                          </form>
                      </Form>
                   ): (
                      <div className="flex items-center justify-center h-full bg-muted rounded-md border-2 border-dashed">
                          <p className="text-muted-foreground text-center p-6">
                              {quiz ? "Select a question to edit or click 'Add New Question' to begin." : "You must create the quiz before adding questions."}
                          </p>
                      </div>
                   )}
              </div>
              )}
          </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Are you absolutely sure?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the entire quiz "<strong>{quiz?.title}</strong>" and all its questions. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button 
              variant="destructive"
              onClick={handleConfirmDeleteQuiz}
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Yes, Delete Quiz
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
