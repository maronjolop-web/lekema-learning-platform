
'use client';

import React, { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Lesson } from '@/lib/definitions';
import { DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { useFirestore } from '@/firebase';
import { doc, collection } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { setDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { sendNotification } from '@/firebase/notifications';

const formSchema = z.object({
  title: z.string().min(3, { message: 'Title must be at least 3 characters.' }),
  description: z.string().min(10, { message: 'Description must be at least 10 characters.' }),
  youtubeLink: z.string().url({ message: 'Please enter a valid YouTube URL.' }),
});

interface LessonFormProps {
  children: React.ReactNode;
  lesson?: Lesson;
}

export default function LessonForm({ children, lesson }: LessonFormProps) {
  const { toast } = useToast();
  const db = useFirestore();
  const [open, setOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: lesson?.title || '',
      description: lesson?.description || '',
      youtubeLink: lesson?.youtubeLink || '',
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    try {
      if (lesson) {
        const docRef = doc(db, 'lessons', lesson.id);
        setDocumentNonBlocking(docRef, values, { merge: true });
        
        sendNotification(db, {
          userId: 'all',
          title: 'Lesson Updated',
          body: `The lesson "${values.title}" has been updated with new content.`,
          type: 'lesson'
        });

        toast({ title: 'Success', description: 'Lesson updated successfully.' });
      } else {
        const colRef = collection(db, 'lessons');
        addDocumentNonBlocking(colRef, values);

        sendNotification(db, {
          userId: 'all',
          title: 'New Lesson Available',
          body: `A new lesson "${values.title}" has been added. Check it out now!`,
          type: 'lesson'
        });

        toast({ title: 'Success', description: 'Lesson created successfully.' });
        form.reset();
      }
      setOpen(false);
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: lesson ? `lessons/${lesson.id}` : 'lessons',
        operation: lesson ? 'update' : 'create',
        requestResourceData: values,
      }));
    }
  };

  const handleDelete = () => {
    if(!lesson) return;
    try {
      const docRef = doc(db, 'lessons', lesson.id);
      deleteDocumentNonBlocking(docRef);
      toast({ title: 'Success', description: 'Lesson deleted successfully.' });
      setDeleteDialogOpen(false);
      setOpen(false);
    } catch (error: any) {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `lessons/${lesson.id}`,
        operation: 'delete',
      }));
    }
  }

  const renderChildren = () => {
    if (!lesson) return children;

    return React.cloneElement(children as React.ReactElement, {
        children: React.Children.map(
            (children as React.ReactElement).props.children,
            (child: React.ReactNode) => {
                if(React.isValidElement(child) && child.type === DropdownMenuContent) {
                    return React.cloneElement(child as React.ReactElement, {
                        children: React.Children.map(child.props.children, (ddChild) => {
                            if (React.isValidElement(ddChild) && ddChild.type === DropdownMenuItem) {
                                if(ddChild.props.children === 'Edit') {
                                    return React.cloneElement(ddChild as React.ReactElement, { onSelect: () => setOpen(true) });
                                }
                                if(ddChild.props.children === 'Delete') {
                                    return React.cloneElement(ddChild as React.ReactElement, { onSelect: (e:Event) => {e.preventDefault(); setDeleteDialogOpen(true)} });
                                }
                            }
                            return ddChild;
                        })
                    });
                }
                return child;
            }
        )
    });
  };

  return (
    <>
    <Dialog open={open} onOpenChange={setOpen}>
      {!lesson && <DialogTrigger asChild>{children}</DialogTrigger>}
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{lesson ? 'Edit Lesson' : 'Create Lesson'}</DialogTitle>
          <DialogDescription>
            {lesson ? 'Make changes to your lesson here.' : 'Add a new lesson to the platform.'} Click save when you&apos;re done.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Introduction to..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="This lesson covers..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="youtubeLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>YouTube Link</FormLabel>
                  <FormControl>
                    <Input placeholder="https://www.youtube.com/watch?v=..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit">
                Save changes
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
    
    {lesson && renderChildren()}

     <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the lesson and any associated quizzes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={handleDelete}>
              Continue
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
