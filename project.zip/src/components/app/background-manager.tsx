'use client';

/**
 * BackgroundManager is deprecated.
 * Global background logic has been moved to RootLayout and globals.css
 * for zero-latency paint and maximum stability on all devices.
 */
export default function BackgroundManager() {
  return null;
}
