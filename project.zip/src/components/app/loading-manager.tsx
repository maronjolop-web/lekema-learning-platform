'use client';

import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

/**
 * LoadingManager handles the progressive loading of the global background
 * and provides a global loading screen for elite stability.
 * Ensures the 'loaded' class is added to the body to reveal the high-res background.
 */
export default function LoadingManager() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Reveal strategy: Wait for initial assets then reveal app
    const handleLoad = () => {
      // Force hardware-accelerated background reveal
      document.body.classList.add('loaded');
      
      // Short delay to ensure browser painting is ready
      setTimeout(() => {
        setIsLoaded(true);
      }, 1000);
    };

    if (document.readyState === 'complete') {
      handleLoad();
    } else {
      window.addEventListener('load', handleLoad);
      // Safety Fallback: Reveal after 4 seconds regardless of network speed
      const timer = setTimeout(handleLoad, 4000);
      return () => {
        window.removeEventListener('load', handleLoad);
        clearTimeout(timer);
      };
    }
  }, []);

  if (isLoaded) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background pointer-events-none transition-opacity duration-700 opacity-100">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="text-sm font-black text-primary tracking-[0.3em] uppercase animate-pulse">Launching LeKeMa...</p>
      </div>
    </div>
  );
}