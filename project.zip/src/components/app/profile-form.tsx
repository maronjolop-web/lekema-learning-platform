'use client';

import React, { useState, useTransition, useRef } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, User as UserIcon, ShieldCheck, Trophy, Zap } from 'lucide-react';
import { User } from '@/lib/definitions';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { useTranslation } from '@/hooks/use-translation';
import { doc, updateDoc } from 'firebase/firestore';
import { useFirestore } from '@/firebase';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { useAuth } from '@/lib/auth';
import { Badge } from '../ui/badge';

const formSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  avatarUrl: z.string().optional(),
  language: z.string().min(1, { message: 'Please select a language.' }),
});

interface ProfileFormProps {
  children: React.ReactNode;
  user: User;
}

const languages = [
  { label: 'English', value: 'English' },
  { label: 'Tagalog', value: 'Tagalog' },
  { label: 'Bisaya', value: 'Bisaya' },
  { label: 'Hiligaynon', value: 'Hiligaynon' },
  { label: 'Spanish', value: 'Spanish' },
  { label: 'French', value: 'French' },
  { label: 'Chinese', value: 'Chinese' },
  { label: 'Japanese', value: 'Japanese' },
];

export default function ProfileForm({ children, user }: ProfileFormProps) {
  const { toast } = useToast();
  const { t } = useTranslation();
  const db = useFirestore();
  const { user: currentUser } = useAuth();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const isOwnProfile = currentUser?.id === user.id;

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: user?.name || '',
      avatarUrl: user?.avatarUrl || '',
      language: user?.language || 'English',
    },
  });
  
  const avatarUrl = form.watch('avatarUrl');

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    if (!isOwnProfile) return;
    
    startTransition(async () => {
      try {
        const userRef = doc(db, 'users', user.id);
        await updateDoc(userRef, {
          name: values.name,
          avatarUrl: values.avatarUrl || user.avatarUrl,
          language: values.language,
        });
        
        toast({ title: 'Success', description: 'Profile updated successfully.' });
        setOpen(false);
      } catch (error: any) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: error.message || 'Failed to update profile.',
        });
      }
    });
  };
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!isOwnProfile) return;
    const file = event.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            form.setValue('avatarUrl', reader.result as string, { shouldValidate: true });
        };
        reader.readAsDataURL(file);
    }
  };

  const getInitials = (name: string) => {
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`;
    }
    return name ? name.substring(0, 2) : '';
  };
  
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent side="right" className="sm:max-w-[400px] p-0 flex flex-col h-full border-l-2">
        <SheetHeader className="p-6 pb-2 bg-muted/10">
          <SheetTitle className="font-headline text-2xl flex items-center gap-2">
            {isOwnProfile ? (
              <><Zap className="h-5 w-5 text-primary" /> {t('edit_profile')}</>
            ) : (
              <><UserIcon className="h-5 w-5 text-primary" /> User Identity</>
            )}
          </SheetTitle>
          <SheetDescription>
            {isOwnProfile 
              ? 'Update your identity and personalized settings.' 
              : `Viewing public information for ${user.name}.`}
          </SheetDescription>
        </SheetHeader>
        
        <ScrollArea className="flex-1 px-6">
          <div className="space-y-8 pb-10">
            <div className="flex flex-col items-center gap-4 py-8">
                <div className="relative group">
                  <Avatar className="h-32 w-32 border-4 border-background shadow-xl ring-4 ring-primary/10">
                      <AvatarImage src={avatarUrl} alt={user.name} />
                      <AvatarFallback className="text-4xl bg-primary text-primary-foreground font-black">
                        {getInitials(form.getValues('name'))}
                      </AvatarFallback>
                  </Avatar>
                  {isOwnProfile && (
                    <Button 
                      type="button" 
                      variant="secondary" 
                      size="icon" 
                      className="absolute bottom-0 right-0 rounded-full shadow-lg border-2 border-background"
                      onClick={() => avatarInputRef.current?.click()}
                    >
                        <Upload className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                
                <div className="text-center space-y-1">
                  <h3 className="text-xl font-bold font-headline">{user.name}</h3>
                  <div className="flex items-center justify-center gap-2">
                    <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20">
                      {user.role === 'admin' ? <ShieldCheck className="h-3 w-3 mr-1" /> : <Trophy className="h-3 w-3 mr-1" />}
                      {user.role}
                    </Badge>
                    <Badge variant="secondary" className="font-bold tabular-nums">
                      {user.points} {t('points_short')}
                    </Badge>
                  </div>
                </div>

                {isOwnProfile && (
                  <input
                      type="file"
                      ref={avatarInputRef}
                      className="hidden"
                      onChange={handleFileChange}
                      accept="image/*"
                    />
                )}
            </div>

            <Separator className="bg-primary/10" />

            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-[0.2em] text-muted-foreground">Detailed Information</h4>
              <Form {...form}>
                <form id="profile-form" onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-bold text-foreground/80">{t('full_name')}</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="John Doe" 
                            {...field} 
                            className="h-12 bg-muted/20 border-border/50 focus:border-primary" 
                            disabled={!isOwnProfile}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="language"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-bold text-foreground/80">{t('preferred_language')}</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!isOwnProfile}>
                          <FormControl>
                            <SelectTrigger className="h-12 bg-muted/20 border-border/50">
                              <SelectValue placeholder="Select a language" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {languages.map((lang) => (
                              <SelectItem key={lang.value} value={lang.value}>
                                {lang.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-2">
                    <FormLabel className="text-sm font-bold text-foreground/80">Account Status</FormLabel>
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/30 border border-dashed">
                      <div className={`h-2 w-2 rounded-full ${user.isBlocked ? 'bg-destructive' : 'bg-green-500'}`} />
                      <span className="text-sm font-medium">{user.isBlocked ? 'Access Restricted' : 'Active Member'}</span>
                    </div>
                  </div>
                </form>
              </Form>
            </div>
          </div>
        </ScrollArea>
        
        {isOwnProfile && (
          <SheetFooter className="p-6 pt-2 border-t bg-muted/20">
              <Button type="submit" form="profile-form" disabled={isPending} className="w-full h-14 text-lg premium-btn">
                  {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t('update_profile')}
              </Button>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  );
}
