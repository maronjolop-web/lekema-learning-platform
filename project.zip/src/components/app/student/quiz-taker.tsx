'use client';

import { useState, useCallback } from 'react';
import { Quiz } from '@/lib/definitions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { CheckCircle2, XCircle, Trophy, RotateCcw, Loader2, ArrowRight, Star } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from '@/hooks/use-translation';

interface QuizTakerProps {
  quiz: Quiz;
}

export default function QuizTaker({ quiz }: QuizTakerProps) {
  const { user, updateUserPoints } = useAuth();
  const { t } = useTranslation();
  const { toast } = useToast();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [identificationInput, setIdentificationInput] = useState('');
  const [score, setScore] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const question = quiz.questions[currentQuestionIndex];
  const totalQuestions = quiz.questions.length;
  const progress = totalQuestions > 0 ? (currentQuestionIndex / totalQuestions) * 100 : 0;

  const handleAction = useCallback(() => {
    if (isAnswered) {
      // Logic for Next Question
      setIsAnswered(false);
      setSelectedAnswer(null);
      setIdentificationInput('');
      
      if (currentQuestionIndex < totalQuestions - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        setQuizFinished(true);
        if (user) {
          // Points update is handled asynchronously
          updateUserPoints(user.id, score);
          toast({
            title: t('quiz_complete'),
            description: `${t('you_earned')} ${score} ${t('points_short')}!`,
          });
        }
      }
    } else {
      // Logic for Submitting Answer
      const finalAnswer = quiz.difficulty === 'Hard' ? identificationInput.trim() : selectedAnswer;
      
      if (!finalAnswer && quiz.difficulty !== 'Hard') return;
      if (quiz.difficulty === 'Hard' && !identificationInput.trim()) return;

      setIsSubmitting(true);
      
      const isCorrect = quiz.difficulty === 'Hard' 
        ? identificationInput.trim().toLowerCase() === question.correctAnswer.toLowerCase()
        : finalAnswer === question.correctAnswer;

      if (isCorrect) {
        setScore(prev => prev + question.points);
      }
      
      setIsAnswered(true);
      setIsSubmitting(false);
    }
  }, [isAnswered, currentQuestionIndex, totalQuestions, quiz.difficulty, identificationInput, selectedAnswer, question, score, user, updateUserPoints, toast, t]);

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setIdentificationInput('');
    setScore(0);
    setIsAnswered(false);
    setQuizFinished(false);
  };
  
  if (!quiz || !quiz.questions || quiz.questions.length === 0) {
    return (
      <div className="text-center py-20 bg-background min-h-[400px] flex flex-col items-center justify-center">
        <p className="text-muted-foreground font-medium">This quiz doesn't have any questions yet.</p>
        <Button asChild className="mt-6" variant="outline">
          <Link href="/dashboard/quizzes">Back to Quizzes</Link>
        </Button>
      </div>
    );
  }

  if (quizFinished) {
    return (
      <Card className="w-full max-w-2xl mx-auto border-2 animate-in fade-in zoom-in duration-500 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-primary" />
        <CardHeader className="text-center pb-2 pt-10">
          <div className="mx-auto bg-primary/10 p-6 rounded-full w-fit mb-6 relative">
            <Trophy className="h-16 w-16 text-primary animate-bounce" />
            <Star className="absolute -top-1 -right-1 h-8 w-8 text-yellow-500 fill-yellow-500 animate-pulse" />
          </div>
          <CardTitle className="text-5xl font-headline mt-2 text-primary font-black tracking-tight">{t('quiz_complete')}</CardTitle>
          <CardDescription className="text-xl font-medium mt-2">Amazing job finishing "{quiz.title}"!</CardDescription>
        </CardHeader>
        <CardContent className="text-center py-12">
          <p className="text-muted-foreground font-bold uppercase tracking-widest text-sm mb-2">{t('you_earned')}</p>
          <div className="flex items-center justify-center gap-3">
            <span className="text-8xl font-black text-primary tabular-nums drop-shadow-sm">{score}</span>
            <span className="text-2xl font-black text-muted-foreground mt-8 uppercase tracking-tighter">{t('points_short')}</span>
          </div>
        </CardContent>
        <CardFooter className="flex-col sm:flex-row gap-4 pt-8 pb-10 border-t bg-muted/30 px-8">
            <Button onClick={restartQuiz} variant="outline" className="w-full h-14 text-lg">
                <RotateCcw className="mr-2 h-5 w-5" />
                {t('try_again')}
            </Button>
            <Button asChild className="premium-btn w-full h-14 text-lg glow">
                <Link href="/dashboard/quizzes" prefetch={false}>
                    {t('back_to_quizzes')}
                </Link>
            </Button>
        </CardFooter>
      </Card>
    );
  }

  const difficultyColor = {
    'Easy': 'bg-green-100 text-green-800 border-green-200',
    'Normal': 'bg-blue-100 text-blue-800 border-blue-200',
    'Hard': 'bg-red-100 text-red-800 border-red-200'
  };

  const isButtonDisabled = isSubmitting || (!isAnswered && (quiz.difficulty === 'Hard' ? !identificationInput.trim() : !selectedAnswer));

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-2xl border-2 overflow-hidden bg-card/95 backdrop-blur-md transition-all duration-500">
      <CardHeader className="bg-muted/30 pb-6 border-b">
        <div className="flex justify-between items-center mb-6">
          <Badge className={cn("text-xs font-black uppercase tracking-widest px-4 py-1.5 border shadow-sm", difficultyColor[quiz.difficulty])}>
            {t(quiz.difficulty.toLowerCase())} {t('difficulty')}
          </Badge>
          <div className="flex items-center gap-2 text-primary font-black">
            <Star className="h-5 w-5 fill-primary" />
            <span className="text-sm tracking-tighter">{question.points} {t('points_short')}</span>
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between text-xs font-black text-muted-foreground uppercase tracking-widest">
            <span>{Math.round(progress)}% Progress</span>
            <span>Question {currentQuestionIndex + 1} of {totalQuestions}</span>
          </div>
          <Progress value={progress} className="h-3 transition-all duration-700 ease-in-out" />
        </div>
      </CardHeader>
      <CardContent className="pt-10 pb-8 px-8">
        <div className="mb-10">
          <h2 className="text-xs font-black text-muted-foreground uppercase tracking-[0.3em] mb-3">Assessment Query</h2>
          <p className="text-3xl font-bold font-headline text-foreground leading-tight tracking-tight">{question.question}</p>
        </div>
        
        {quiz.difficulty === 'Hard' ? (
          <div className="space-y-6">
            <Input 
              placeholder="Type your answer here..."
              value={identificationInput}
              onChange={(e) => setIdentificationInput(e.target.value)}
              disabled={isAnswered || isSubmitting}
              autoFocus
              className={cn(
                "h-16 text-2xl px-6 transition-all duration-300 shadow-inner bg-muted/20 font-bold",
                isAnswered && identificationInput.trim().toLowerCase() === question.correctAnswer.toLowerCase() && "border-green-500 bg-green-50 ring-2 ring-green-500",
                isAnswered && identificationInput.trim().toLowerCase() !== question.correctAnswer.toLowerCase() && "border-red-500 bg-red-50 ring-2 ring-red-500"
              )}
            />
            {isAnswered && (
               <div className={cn(
                 "p-6 rounded-2xl flex items-center gap-6 border-2 animate-in slide-in-from-top-4 duration-500",
                 identificationInput.trim().toLowerCase() === question.correctAnswer.toLowerCase() ? "bg-green-100 border-green-200 text-green-900 shadow-md" : "bg-red-100 border-red-200 text-red-900 shadow-md"
               )}>
                 {identificationInput.trim().toLowerCase() === question.correctAnswer.toLowerCase() 
                   ? <CheckCircle2 className="h-8 w-8 shrink-0 text-green-600" />
                   : <XCircle className="h-8 w-8 shrink-0 text-red-600" />
                 }
                 <div>
                   <p className="text-xs font-black uppercase tracking-widest mb-1">Correct Identity</p>
                   <p className="font-bold text-2xl">{question.correctAnswer}</p>
                 </div>
               </div>
            )}
          </div>
        ) : (
          <RadioGroup
            value={selectedAnswer ?? ''}
            onValueChange={setSelectedAnswer}
            disabled={isAnswered || isSubmitting}
            className="gap-4"
          >
            {question.choices.map((choice, index) => {
              const isCorrect = choice === question.correctAnswer;
              const isSelected = choice === selectedAnswer;
              
              let displayChoice = choice;
              if (quiz.difficulty === 'Easy') {
                if (choice === 'True') displayChoice = t('true');
                if (choice === 'False') displayChoice = t('false');
              }

              return (
                <Label
                  key={index}
                  className={cn(
                    'flex items-center space-x-4 rounded-2xl border-2 p-6 transition-all relative overflow-hidden group',
                    !isAnswered && 'cursor-pointer hover:border-primary/50 hover:bg-primary/5 active:scale-[0.98]',
                    isSelected && 'border-primary bg-primary/10 ring-2 ring-primary/20',
                    isAnswered && isCorrect && 'border-green-500 bg-green-500/20',
                    isAnswered && isSelected && !isCorrect && 'border-red-500 bg-red-500/20',
                    isAnswered && !isSelected && 'opacity-50 grayscale-[0.5]'
                  )}
                >
                  <RadioGroupItem value={choice} className="sr-only" />
                  <div className={cn(
                    "h-7 w-7 rounded-full border-2 flex items-center justify-center shrink-0 transition-all duration-300",
                    isSelected ? "border-primary scale-110 shadow-md" : "border-muted-foreground/30",
                    isAnswered && isCorrect && "border-green-500 bg-green-500",
                    isAnswered && isSelected && !isCorrect && "border-red-500 bg-red-500"
                  )}>
                    {isSelected && !isAnswered && <div className="h-3.5 w-3.5 rounded-full bg-primary animate-in zoom-in" />}
                    {isAnswered && isCorrect && <CheckCircle2 className="h-5 w-5 text-white" />}
                    {isAnswered && isSelected && !isCorrect && <XCircle className="h-5 w-5 text-white" />}
                  </div>
                  <span className="text-xl font-bold leading-tight flex-1 tracking-tight">{displayChoice}</span>
                  {isAnswered && isCorrect && !isSelected && <CheckCircle2 className="ml-auto h-7 w-7 text-green-500 shrink-0" />}
                </Label>
              );
            })}
          </RadioGroup>
        )}
      </CardContent>
      <CardFooter className="pb-10 pt-6 px-8">
        <Button 
          onClick={handleAction} 
          className={cn(
            "premium-btn w-full h-16 text-2xl font-black transition-all duration-500 glow",
            !isButtonDisabled && !isAnswered && "hover:shadow-2xl hover:-translate-y-1"
          )}
          disabled={isButtonDisabled}
        >
          {isSubmitting ? (
            <Loader2 className="h-8 w-8 animate-spin" />
          ) : isAnswered ? (
            <>
               <span>{currentQuestionIndex < totalQuestions - 1 ? t('next_question') : t('finish_quiz')}</span>
               <ArrowRight className="ml-3 h-7 w-7" />
            </>
          ) : (
            t('submit_answer')
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}