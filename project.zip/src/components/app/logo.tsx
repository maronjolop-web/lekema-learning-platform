
'use client';

import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

/**
 * Standardized Logo component using Next.js Image optimization.
 * Refers to local assets in /public/assets for reliable production delivery.
 */
export default function Logo() {
  const logoImage = PlaceHolderImages.find(p => p.id === 'app-logo');

  // Fallback if local asset is missing
  if (!logoImage || !logoImage.imageUrl) {
    return (
      <div 
        className="h-6 w-6 rounded-md bg-primary flex items-center justify-center text-[10px] font-black text-white"
      >
        LKM
      </div>
    );
  }

  return (
    <Image
      src={logoImage.imageUrl}
      alt="LeKeMa Logo"
      width={24}
      height={24}
      className="h-6 w-6 rounded-md object-contain"
      priority
    />
  );
}
