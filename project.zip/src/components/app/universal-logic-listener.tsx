
'use client';

import { useEffect } from 'react';

/**
 * UniversalLogicListener
 * Minimalized to handle only essential global form preventions.
 * Admin toggles are now handled by component-level React state for stability.
 */
export default function UniversalLogicListener() {
  useEffect(() => {
    const handleSubmit = (e: SubmitEvent) => {
      const target = e.target as HTMLElement;
      if (target.matches('.upload-form') || target.matches('.chat-form')) {
        e.preventDefault();
      }
    };

    document.addEventListener('submit', handleSubmit);
    return () => {
      document.removeEventListener('submit', handleSubmit);
    };
  }, []);

  return null;
}
