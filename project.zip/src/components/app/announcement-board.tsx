'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { useAuth } from '@/lib/auth';
import { Bell, Loader2, Megaphone, Pencil, Trash2, Settings, PlusCircle } from 'lucide-react';
import { Announcement } from '@/lib/definitions';
import { formatDistanceToNow } from 'date-fns';
import AnnouncementForm from './admin/announcement-form';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/**
 * Public Announcements and Activities component.
 * Features state-managed Admin Controls for high stability.
 */
export default function AnnouncementBoard() {
  const { user, role } = useAuth();
  const db = useFirestore();
  const [showAdminControls, setShowAdminControls] = useState(false);
  
  const isAdmin = role === 'admin' || user?.email === 'lekema@gmail.com';

  const announcementsQuery = useMemoFirebase(() => 
    query(collection(db, 'announcements'), orderBy('createdAt', 'desc'), limit(15)),
  [db]);

  const { data: announcements, isLoading } = useCollection<Announcement>(announcementsQuery);

  return (
    <Card className="panel border-2 shadow-md overflow-hidden h-full bg-card">
      <CardHeader className="bg-primary/5 pb-4 border-b">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Megaphone className="h-5 w-5 text-primary" />
            <CardTitle className="font-headline text-primary text-xl md:text-2xl">Public Announcements and Activities</CardTitle>
          </div>
          {isAdmin && (
            <div className="flex items-center gap-2">
                <AnnouncementForm>
                    <button className="p-2 rounded-full hover:bg-primary/10 transition-colors text-primary" title="Post New Note">
                        <PlusCircle className="h-6 w-6" />
                    </button>
                </AnnouncementForm>
                <button 
                  className={cn(
                    "p-2 rounded-full transition-all duration-200",
                    showAdminControls ? "bg-primary text-white rotate-90" : "hover:bg-primary/10 text-primary"
                  )}
                  onClick={() => setShowAdminControls(!showAdminControls)}
                  title="Admin Settings"
                >
                    <Settings className="h-5 w-5" />
                </button>
            </div>
          )}
        </div>
        <CardDescription>Important notes and activity updates from administrators.</CardDescription>
      </CardHeader>
      <CardContent className="pt-6 space-y-6 px-4 md:px-6">
        {isAdmin && showAdminControls && (
          <div className="p-4 rounded-xl bg-muted/20 border-2 border-dashed border-primary/30 animate-in slide-in-from-top-2 duration-300">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] mb-4 text-primary">Administrative Controls</h4>
            <div className="grid grid-cols-1 gap-3">
               <AnnouncementForm>
                  <Button variant="outline" className="w-full justify-start h-12 text-xs font-bold gap-3 premium-btn !bg-primary !text-white">
                    <PlusCircle className="h-4 w-4" /> Create New Public Note
                  </Button>
               </AnnouncementForm>
               <Button 
                 variant="ghost" 
                 className="w-full justify-start h-12 text-xs font-bold gap-3 text-destructive hover:bg-destructive/10"
                 onClick={() => {
                   // Purge logic could be added here
                 }}
               >
                  <Trash2 className="h-4 w-4" /> Purge Expired Activities
               </Button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {isLoading ? (
            <div className="flex justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : announcements?.map((ann) => (
            <div key={ann.id} className="p-4 rounded-xl bg-background border-2 border-primary shadow-sm animate-in fade-in slide-in-from-left-2 duration-300 group">
              <p className="text-sm font-bold leading-relaxed mb-3 text-foreground whitespace-pre-wrap">{ann.text}</p>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[10px] uppercase tracking-widest font-black text-muted-foreground border-t pt-3">
                <div className="flex wrap items-center gap-3">
                   <span className="text-primary font-bold">By {ann.authorName}</span>
                   {isAdmin && (
                     <AnnouncementForm announcement={ann}>
                        <button 
                            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-primary/20 bg-primary/5 text-primary hover:bg-primary/10 transition-colors cursor-pointer"
                            title="Edit Update"
                        >
                            <Pencil className="h-3.5 w-3.5" />
                            <span className="text-[9px] font-black">Manage Post</span>
                        </button>
                     </AnnouncementForm>
                   )}
                </div>
                <span className="font-medium text-foreground/60 shrink-0">
                  {ann.createdAt?.seconds 
                    ? formatDistanceToNow(new Date(ann.createdAt.seconds * 1000)) + ' ago' 
                    : 'Just now'}
                </span>
              </div>
            </div>
          ))}
          {announcements?.length === 0 && !isLoading && (
            <div className="text-center py-10 opacity-50">
              <Bell className="h-10 w-10 text-muted-foreground/20 mx-auto mb-2" />
              <p className="text-sm font-bold uppercase tracking-widest">No recent activities.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}