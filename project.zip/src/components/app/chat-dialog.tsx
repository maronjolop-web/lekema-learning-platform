'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  limit, 
  doc, 
  serverTimestamp,
  addDoc,
  setDoc,
} from 'firebase/firestore';
import { useAuth } from '@/lib/auth';
import { MessageSquare, Send, Loader2 } from 'lucide-react';
import { Message, User as AppUser } from '@/lib/definitions';
import { cn } from '@/lib/utils';
import { sendNotification } from '@/firebase/notifications';

interface ChatDialogProps {
  targetUser: AppUser;
  trigger?: React.ReactNode;
}

export default function ChatDialog({ targetUser, trigger }: ChatDialogProps) {
  const { user: currentUser } = useAuth();
  const db = useFirestore();
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [convoId, setConvoId] = useState<string | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!currentUser || !targetUser) return;
    const ids = [currentUser.id, targetUser.id].sort();
    setConvoId(`${ids[0]}_${ids[1]}`);
  }, [currentUser, targetUser]);

  const messagesQuery = useMemoFirebase(() => {
    if (!convoId) return null;
    return query(
      collection(db, 'conversations', convoId, 'messages'),
      orderBy('createdAt', 'asc'),
      limit(100)
    );
  }, [db, convoId]);

  const { data: messages, isLoading } = useCollection<Message>(messagesQuery);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (viewportRef.current) {
        viewportRef.current.scrollTo({
          top: viewportRef.current.scrollHeight,
          behavior: 'smooth'
        });
      }
    }, 150);
    return () => clearTimeout(timer);
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !currentUser || !convoId || isSending) return;

    setIsSending(true);
    const messageText = message.trim();

    try {
      const convoRef = doc(db, 'conversations', convoId);
      
      setDoc(convoRef, {
        participants: [currentUser.id, targetUser.id],
        lastMessage: messageText,
        updatedAt: serverTimestamp(),
      }, { merge: true });

      const messagesCol = collection(db, 'conversations', convoId, 'messages');
      await addDoc(messagesCol, {
        senderId: currentUser.id,
        text: messageText,
        createdAt: serverTimestamp(),
      });

      // Notify recipient
      sendNotification(db, {
        userId: targetUser.id,
        title: `New Message from ${currentUser.name}`,
        body: messageText,
        type: 'message'
      });

      setMessage('');
    } catch (err) {
      console.error("Failed to send message:", err);
    } finally {
      setIsSending(false);
    }
  };

  const getInitials = (name: string) => name ? name.substring(0, 2).toUpperCase() : '??';

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm" className="gap-2 premium-btn !py-2 !px-4 !h-auto !text-xs">
            <MessageSquare className="h-4 w-4" /> Message
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[450px] h-[600px] flex flex-col p-0 overflow-hidden bg-card shadow-2xl border-2">
        <DialogHeader className="p-4 border-b bg-primary/5">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10 border-2 border-primary/20 shadow-sm">
              <AvatarImage src={targetUser.avatarUrl} alt={targetUser.name} />
              <AvatarFallback className="bg-primary/10 text-primary">{getInitials(targetUser.name)}</AvatarFallback>
            </Avatar>
            <div>
              <DialogTitle className="text-lg font-headline text-primary font-bold">{targetUser.name}</DialogTitle>
              <p className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">
                {targetUser.role === 'admin' ? 'Support Channel' : 'Private Conversation'}
              </p>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 p-4" viewportRef={viewportRef}>
          <div className="space-y-4 pb-6">
            {messages?.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  "flex flex-col max-w-[85%] gap-1 animate-in fade-in slide-in-from-bottom-2 duration-300",
                  msg.senderId === currentUser?.id ? "ml-auto items-end" : "mr-auto items-start"
                )}
              >
                <div
                  className={cn(
                    "px-4 py-2.5 rounded-2xl text-sm font-semibold shadow-sm",
                    msg.senderId === currentUser?.id
                      ? "bg-primary text-white rounded-tr-none shadow-md"
                      : "bg-muted text-[#001a33] rounded-tl-none border shadow-sm"
                  )}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            )}
            {messages?.length === 0 && !isLoading && (
              <div className="flex flex-col items-center justify-center py-24 text-muted-foreground text-center gap-4">
                <div className="bg-primary/5 p-6 rounded-full">
                  <MessageSquare className="h-12 w-12 text-primary opacity-30" />
                </div>
                <p className="text-sm font-bold text-[#001a33]/60">No messages yet.<br/>Start the conversation!</p>
              </div>
            )}
          </div>
          <ScrollBar orientation="vertical" />
        </ScrollArea>

        <div className="p-4 border-t bg-muted/30">
          <form onSubmit={handleSendMessage} className="flex gap-2 items-center">
            <div className="flex-1 relative">
              <Input
                placeholder="Write a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                disabled={isSending}
                className="h-12 bg-background border-2 pr-12 focus-visible:ring-primary font-medium text-foreground"
              />
            </div>
            <Button 
              type="submit" 
              size="icon" 
              disabled={!message.trim() || isSending} 
              className="h-12 w-12 rounded-full shadow-lg premium-btn !p-0"
            >
              {isSending ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}