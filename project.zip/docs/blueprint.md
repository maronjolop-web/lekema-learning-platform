# **App Name**: LeKeMa Learning Platform

## Core Features:

- Admin Authentication: Secure admin login using predefined email (LeKeMa@gmail.com) and password (LeKeMa2026) credentials, with restricted access to the admin dashboard upon successful authentication.
- Student Registration and Login: Allow students to create accounts and log in securely to access the student dashboard.
- Lesson Display (Students): Display lesson titles, descriptions, and embedded YouTube videos in a read-only format for students.
- Quiz Taking: Enable students to answer quizzes, earn points for correct answers, and track their total score.
- Leaderboard: Display a ranked list of students based on their total points, sorted from highest to lowest.
- Classmates List: Allow students to view a list of classmates using the app with basic information.
- Lesson Management (Admin): Enable admins to create, edit, and delete lessons, including uploading YouTube video links.
- Quiz Management (Admin): Enable admins to create, edit, and delete quizzes, and set question types and points per question.
- Member Management (Admin): Enable admins to view all members, block/unblock members, with blocked members unable to log in or earn points.

## Style Guidelines:

- Primary color: Deep Blue (#1E3A8A) to create a professional and trustworthy environment.
- Background color: Light Gray (#F9FAFB), almost white, for a clean and distraction-free learning environment.
- Accent color: Sky Blue (#0EA5E9) for interactive elements and highlights, providing a sense of calm and clarity.
- Body font: 'PT Sans', a humanist sans-serif suitable for body text.
- Headline font: 'Space Grotesk', a proportional sans-serif suitable for headlines and short amounts of body text.
- Use consistent and clear icons for navigation and lesson categories, promoting ease of use.
- Employ a clean and structured layout with clear visual hierarchy to help students focus on learning materials.
- Use subtle animations for UI transitions and feedback on quizzes, creating an engaging user experience.